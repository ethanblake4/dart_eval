from pathlib import Path
import hashlib, io, json, subprocess, zipfile

root = Path(__file__).resolve().parent
repo = root.parents[1]
cfg = repo.parent / 'control_flow_graph'
entries = {}
for variant, revision in [('before', '9e96620'), ('after', 'f77d892')]:
    data = subprocess.check_output(['git', 'archive', '--format=zip', revision, 'lib', 'pubspec.yaml'], cwd=cfg)
    with zipfile.ZipFile(io.BytesIO(data)) as source:
        for name in source.namelist():
            if not name.endswith('/'):
                entries[f'cfg-{variant}/{name}'] = source.read(name)
    for path in (root / variant).iterdir():
        if path.name == 'cases.json' or path.name == 'prepare.jsonl' or path.suffix == '.evc' or path.name.endswith('.bytecode.txt'):
            entries[path.relative_to(root).as_posix()] = path.read_bytes()
for path in (root / 'workloads').glob('*.dart'):
    entries[path.relative_to(root).as_posix()] = path.read_bytes()
for path in root.iterdir():
    if path.name in ['audit.dart','compare.ps1','restore.py','bundle.py','README.md'] or path.name.startswith('paired') or path.name.endswith(('-tests.log','-analyze.log')):
        entries[path.name] = path.read_bytes()
entries['report.md'] = (repo / 'docs/allocator-swaps-2026-09-16.md').read_bytes()
entries['sha256.json'] = json.dumps({name:hashlib.sha256(data).hexdigest() for name,data in entries.items()},indent=2).encode()
destination = repo / 'docs/allocator-swap-evidence.zip'
with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name,data in sorted(entries.items()): archive.writestr(name,data)
with zipfile.ZipFile(destination) as archive:
    assert archive.testzip() is None
print(destination, len(entries), destination.stat().st_size)
