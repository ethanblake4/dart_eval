from pathlib import Path
from urllib.parse import urljoin
import json, sys

root = Path(__file__).resolve().parent
configuration = Path(sys.argv[1]).resolve()
base = json.loads(configuration.read_text())
for package in base['packages']:
    package['rootUri'] = urljoin(configuration.as_uri(), package['rootUri'])
for variant in ['before', 'after']:
    config = json.loads(json.dumps(base))
    for package in config['packages']:
        if package['name'] == 'control_flow_graph':
            package['rootUri'] = (root / f'cfg-{variant}').as_uri() + '/'
    (root / variant / 'package_config.json').write_text(json.dumps(config, indent=2))
    print('Configured', variant)
