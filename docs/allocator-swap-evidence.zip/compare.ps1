param([int]$Sweep = 1, [int]$Rotation = 8, [int]$Samples = 31)
$ErrorActionPreference = 'Stop'
$before = Join-Path $PSScriptRoot 'before'
$after = Join-Path $PSScriptRoot 'after'
$exe = Join-Path $PSScriptRoot 'audit.exe'
foreach ($phase in @('warmup', 'measure')) {
  $count = if ($phase -eq 'warmup') { 3 } else { $Samples }
  $output = Join-Path $PSScriptRoot "paired$Sweep-$phase.jsonl"
  $errors = Join-Path $PSScriptRoot "paired$Sweep-$phase.stderr"
  $process = Start-Process -FilePath $exe -ArgumentList @($before, 'compare', $after, $count, $Rotation) -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput $output -RedirectStandardError $errors
  $process.ProcessorAffinity = 4
  $process.PriorityClass = 'AboveNormal'
  $process.WaitForExit()
  if ($process.ExitCode -ne 0) { throw "Comparison failed: $(Get-Content $errors -Raw)" }
}
Get-Content (Join-Path $PSScriptRoot "paired$Sweep-measure.jsonl") | ForEach-Object {
  $row = $_ | ConvertFrom-Json
  "$($row.mode) $($row.case) $($row.median_ms)"
}
