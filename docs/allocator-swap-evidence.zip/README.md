# Allocator swap evidence

Baseline: dart_eval c6d69a9, CFG 9e96620. After: same runtime, CFG f77d892.
Dart 3.10.7, Windows x64. Paired results use one AOT executable loading both
payload sets, alternating execution order, 31 samples and two case rotations.
The compare.ps1 script pins CPU affinity 4 and AboveNormal priority, with a
separate warmup process. Native checksum functions are in audit.dart/workloads.

Extract this archive under the dart_eval checkpoint checkout, for example at
`.dart_tool/allocator-swap-evidence`. From the checkout root, build and measure:

```powershell
dart compile exe .dart_tool/allocator-swap-evidence/audit.dart -o .dart_tool/allocator-swap-evidence/audit.exe
.dart_tool/allocator-swap-evidence/compare.ps1 -Sweep 3 -Rotation 8
```

The existing payloads are complete, with envelope/payload versions 104/116.
The two CFG source snapshots are included for recompilation. Reuse dependencies
from the checkpoint checkout without changing its package configuration:

```powershell
python .dart_tool/allocator-swap-evidence/restore.py .dart_tool/package_config.json
dart --packages=.dart_tool/allocator-swap-evidence/before/package_config.json .dart_tool/allocator-swap-evidence/audit.dart .dart_tool/allocator-swap-evidence/before prepare
dart --packages=.dart_tool/allocator-swap-evidence/after/package_config.json .dart_tool/allocator-swap-evidence/audit.dart .dart_tool/allocator-swap-evidence/after prepare
```

cases.json contains the full guest sources and iteration counts. prepare.jsonl
records checksums, code sizes and static opcode counts; its single cold compile
time is diagnostic, not a compilation-speed comparison. The bytecode listings
are decoded VM instructions, not native assembly. Paired measurement files
retain all individual samples and ratios. Tests and analyzer logs describe the
final allocator. There are no cached dependencies or native binaries here.
