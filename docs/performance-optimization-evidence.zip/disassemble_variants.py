from pathlib import Path
import re, subprocess, sys
root=Path(__file__).resolve().parent
llvm=Path('C:/Program Files/LLVM/bin')
for name in sys.argv[1:]:
    path=root/'final' if name=='final' else root/'experiments'/name
    symbols=subprocess.check_output([llvm/'llvm-objdump.exe','--syms',path/'runtime.aot'],text=True)
    (path/'symbols.txt').write_text(symbols)
    match=re.search(r'^([0-9a-f]+)\s+.*\.text\s+([0-9a-f]+)\s+TypedMachine\._dispatch$',symbols,re.M)
    start,size=(int(v,16) for v in match.groups())
    subprocess.run([llvm/'llvm-objcopy.exe','--strip-all',path/'runtime.aot',path/'inspection.elf'],check=True)
    output=subprocess.check_output([llvm/'llvm-objdump.exe','--disassemble-all','--triple=aarch64',f'--start-address=0x{start:x}',f'--stop-address=0x{start+size:x}','--no-show-raw-insn',path/'inspection.elf'],text=True)
    (path/'dispatch.txt').write_text(output)
    print(name,size)
