from pathlib import Path
import json, shutil, subprocess, zipfile
root=Path(__file__).resolve().parent
repository=root.parents[1]
final=root/'final'
for directory in ['lib','tool','benchmark']:
    shutil.copytree(repository/directory, final/directory, dirs_exist_ok=True)
for name in ['pubspec.yaml','pubspec.lock']:
    if (repository/name).exists():shutil.copy2(repository/name,final/name)
shutil.copy2(repository/'docs/performance-optimization-2026-09-16.md',root/'REPORT.md')
manifest={}
for name,path in [('dart_eval',repository),('control_flow_graph',repository.parent/'control_flow_graph')]:
    manifest[name]={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=path,text=True).strip(),'status':subprocess.check_output(['git','status','--short'],cwd=path,text=True)}
manifest['sdk']=subprocess.check_output(['dart','--version'],text=True).strip()
(root/'manifest.json').write_text(json.dumps(manifest,indent=2))
archive=repository/'docs/performance-optimization-evidence.zip'
allowed={'.dart','.yaml','.lock','.py','.md','.json','.jsonl','.txt','.csv','.diff','.log','.evc','.err','.ps1'}
count=0
reference=root/'experiments/reference'
measured={
    'reuse_frames': {'prepare.jsonl','timing.jsonl','calls.txt','calls-stable-2.txt','calls-stable-3.txt','timing-stable-6.jsonl','symbols.txt','dispatch.txt','arm64-summary.json','opcode_addresses.json'},
    'reuse_frames_cached': {'prepare.jsonl','timing-cached-1.jsonl','timing-cached-3.jsonl','calls-cached.txt'},
    'reuse_frames_leaf': {'prepare.jsonl','timing-final-2.jsonl','timing-final-5.jsonl','calls-final.txt'},
    'integer3_hot': {'prepare.jsonl','timing-final-3.jsonl','symbols.txt','dispatch.txt','arm64-summary.json','opcode_addresses.json','extended-map.json'},
}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for path in sorted(root.rglob('*')):
        relative=path.relative_to(root)
        if not path.is_file() or path.suffix not in allowed or '.dart_tool' in relative.parts:continue
        parts=relative.parts
        if len(parts)==3 and parts[0]=='experiments' and parts[1] in measured:
            if path.suffix in {'.txt','.json','.jsonl','.err'} and path.name not in measured[parts[1]]:continue
        project=root/'final' if parts[0]=='final' else root/'experiments'/parts[1] if parts[0]=='experiments' and len(parts)>2 else None
        if project and project.name not in {'reference','control_flow_graph'}:
            inner=path.relative_to(project)
            original=reference/inner
            if inner.parts[0] in {'lib','tool','benchmark'} and original.is_file() and original.read_bytes()==path.read_bytes():continue
        output.write(path,relative.as_posix());count+=1
print(archive,count,'files',archive.stat().st_size,'bytes')
