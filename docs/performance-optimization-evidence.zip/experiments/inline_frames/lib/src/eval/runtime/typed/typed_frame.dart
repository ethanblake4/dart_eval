import 'dart:typed_data';

import 'package:dart_eval/src/eval/runtime/runtime.dart';
import 'package:dart_eval/src/eval/runtime/typed/typed_interop.dart';
import 'package:dart_eval/src/eval/runtime/class.dart';
import 'typed_function.dart';
import 'typed_exception_state.dart';
import 'typed_async.dart';
import 'typed_program.dart';

/// Register initialization happens once at the public host boundary. Internal
/// calls already have their arguments in the compiler-assigned registers.
class TypedEntry {
  /// Recovery and await continuations have a single boxed result in R.
  const TypedEntry.result(this.r)
    : a = 0,
      b = 0,
      f = 0.0,
      g = 0.0,
      e = false,
      x = false,
      s = null,
      c = null,
      environment = const [];

  const TypedEntry.empty()
    : a = 0,
      b = 0,
      f = 0.0,
      g = 0.0,
      e = false,
      x = false,
      r = null,
      s = null,
      c = null,
      environment = const [];

  const TypedEntry.direct({
    this.a = 0,
    this.b = 0,
    this.f = 0.0,
    this.g = 0.0,
    this.e = false,
    this.x = false,
    this.r,
    this.s,
    this.c,
    this.environment = const [],
  });

  static TypedEntry prepare(
    TypedFunction function,
    List<int> integers,
    List<double> doubles,
    List<bool> booleans,
    List<Object?> objects,
    Runtime? runtime,
  ) {
    final layout = function.callLayout;
    var a = 0, b = 0;
    var f = 0.0, g = 0.0;
    var e = false, x = false;
    Object? r, s, c;
    final overflow = layout.overflowCount == 0
        ? null
        : List<Object?>.filled(layout.overflowCount, null);
    var integer = 0, floating = 0, boolean = 0, object = 0;
    for (var i = 0; i < function.argumentKinds.length; i++) {
      final Object? value;
      switch (function.argumentKinds[i]) {
        case TypedArgumentKind.integer:
          if (integer == integers.length) {
            throw ArgumentError('Missing int argument');
          }
          value = integers[integer++];
        case TypedArgumentKind.doublePrecision:
          if (floating == doubles.length) {
            throw ArgumentError('Missing double argument');
          }
          value = doubles[floating++];
        case TypedArgumentKind.boolean:
          if (boolean == booleans.length) {
            throw ArgumentError('Missing bool argument');
          }
          value = booleans[boolean++];
        case TypedArgumentKind.string:
          if (object == objects.length) {
            throw ArgumentError('Missing String argument');
          }
          value = objects[object++] as String;
        case TypedArgumentKind.object:
          if (object == objects.length) {
            throw ArgumentError('Missing object argument');
          }
          value = TypedInterop.boxExternal(objects[object++], runtime: runtime);
      }
      final location = layout.arguments[i];
      if (location.overflowIndex case final index?) {
        overflow![index] = value;
      } else {
        switch (location.bank) {
          case TypedRegisterBank.integer:
            if (location.index == 0) {
              a = value as int;
            } else {
              b = value as int;
            }
          case TypedRegisterBank.doublePrecision:
            if (location.index == 0) {
              f = value as double;
            } else {
              g = value as double;
            }
          case TypedRegisterBank.boolean:
            if (location.index == 0) {
              e = value as bool;
            } else {
              x = value as bool;
            }
          case TypedRegisterBank.object:
            if (location.index == 0) {
              r = value;
            } else if (location.index == 1) {
              s = value;
            } else {
              c = value;
            }
        }
      }
    }
    if (integer != integers.length ||
        floating != doubles.length ||
        boolean != booleans.length ||
        object != objects.length) {
      throw ArgumentError('Too many typed entry arguments');
    }
    if (overflow != null) c = overflow;
    return TypedEntry.direct(
      a: a,
      b: b,
      f: f,
      g: g,
      e: e,
      x: x,
      r: r,
      s: s,
      c: c,
    );
  }

  /// Values already have the physical representations in the signature.
  /// No boxing, argument rebinding, or host conversion occurs here.
  factory TypedEntry.fromValues(
    TypedFunction function,
    List<Object?> values, {
    List<Object?> environment = const [],
  }) {
    if (values.length != function.argumentKinds.length) {
      throw ArgumentError(
        'Expected ${function.argumentKinds.length} arguments, got ${values.length}',
      );
    }
    final layout = function.callLayout;
    var a = 0, b = 0;
    var f = 0.0, g = 0.0;
    var e = false, x = false;
    Object? r, s, c;
    final overflow = layout.overflowCount == 0
        ? null
        : List<Object?>.filled(layout.overflowCount, null);
    for (var i = 0; i < values.length; i++) {
      final location = layout.arguments[i];
      if (location.overflowIndex case final index?) {
        overflow![index] = values[i];
      } else {
        final value = values[i];
        switch (location.bank) {
          case TypedRegisterBank.integer:
            if (location.index == 0) {
              a = value as int;
            } else {
              b = value as int;
            }
          case TypedRegisterBank.doublePrecision:
            if (location.index == 0) {
              f = value as double;
            } else {
              g = value as double;
            }
          case TypedRegisterBank.boolean:
            if (location.index == 0) {
              e = value as bool;
            } else {
              x = value as bool;
            }
          case TypedRegisterBank.object:
            if (location.index == 0) {
              r = value;
            } else if (location.index == 1) {
              s = value;
            } else {
              c = value;
            }
        }
      }
    }
    if (overflow != null) c = overflow;
    return TypedEntry.direct(
      a: a,
      b: b,
      f: f,
      g: g,
      e: e,
      x: x,
      r: r,
      s: s,
      c: c,
      environment: environment,
    );
  }

  final int a, b;
  final double f, g;
  final bool e, x;
  final Object? r, s, c;
  final List<Object?> environment;
}

/// Each active invocation owns spills and one optional outgoing list. A callee
/// receives the caller's list in C and borrows it until returning. It uses its
/// own outgoing list for nested calls, so argument lists need no copy.
class TypedFrame {
  TypedFrame(this.function, [this.parent])
    : intSpills = Int64List(function.intSpillCount),
      doubleSpills = Float64List(function.doubleSpillCount),
      boolSpills = Uint8List(function.boolSpillCount),
      objectSpills = List<Object?>.filled(function.objectSpillCount, null),
      objectOutgoing = function.objectOutgoingCount == 0
          ? const []
          : List<Object?>.filled(function.objectOutgoingCount, null);

  /// Reuse a frame for repeated calls at the same depth. Recursive invocations
  /// still have distinct storage, and every run owns its entire frame chain.
  @pragma('vm:prefer-inline')
  TypedFrame enterStatic(TypedProgram program, int index, int pc) {
    final callee = program.functions[index];
    var child = _child;
    if (child == null || !identical(child.function, callee)) {
      child = _child = TypedFrame(callee, this);
    }
    child.returnPc = pc;
    child.environment = const [];
    return child;
  }

  @pragma('vm:prefer-inline')
  TypedFrame enter(TypedFunction callee, int pc) {
    var child = _child;
    if (child == null || !identical(child.function, callee)) {
      child = _child = TypedFrame(callee, this);
    }
    child.returnPc = pc;
    child.environment = const [];
    return child;
  }

  @pragma('vm:prefer-inline')
  TypedFrame enterClosure(
    TypedFunction callee,
    int pc,
    List<Object?> captures,
  ) {
    // Keep the cached-frame path in one Dart call, just like ordinary calls.
    var child = _child;
    if (child == null || !identical(child.function, callee)) {
      child = _child = TypedFrame(callee, this);
    }
    child.returnPc = pc;
    child.environment = captures;
    return child;
  }

  @pragma('vm:never-inline')
  Object? captureAt(int index) => environment[index];

  @pragma('vm:prefer-inline')
  TypedFrame leave() {
    returnPc = -1;
    // Compiler continuations and exception unwinding have already popped this
    // frame's handlers. Ordinary returns need no handler-state check.
    environment = const [];
    // Cached inactive frames must not retain arbitrary application objects.
    if (objectSpills.isNotEmpty) {
      objectSpills.fillRange(0, objectSpills.length, null);
    }
    if (objectOutgoing.isNotEmpty) {
      objectOutgoing.fillRange(0, objectOutgoing.length, null);
    }
    final caller = parent!;
    if (caller.objectOutgoing.isNotEmpty) {
      caller.objectOutgoing.fillRange(0, caller.objectOutgoing.length, null);
    }
    return caller;
  }

  /// Host callbacks may retain their argument list or reenter the interpreter.
  /// Give them a snapshot, never the VM's mutable outgoing storage.
  @pragma('vm:never-inline')
  List<$Value?> takeObjectArguments(int count) {
    final arguments = List<$Value?>.generate(
      count,
      (i) => objectOutgoing[i] as $Value?,
      growable: false,
    );
    if (objectOutgoing.isNotEmpty) {
      objectOutgoing.fillRange(0, objectOutgoing.length, null);
    }
    return arguments;
  }

  final TypedFunction function;
  TypedExceptionState? exceptions;
  TypedAsyncState? asyncState;
  TypedFrame? parent;
  TypedFrame? _child;
  int returnPc = -1;

  /// A suspended invocation must never be reused by its former caller.
  /// Ordinary calls and returns do not inspect async state.
  @pragma('vm:never-inline')
  void detachAsync() {
    final caller = parent;
    if (caller != null) {
      if (identical(caller._child, this)) caller._child = null;
      if (caller.objectOutgoing.isNotEmpty) {
        caller.objectOutgoing.fillRange(0, caller.objectOutgoing.length, null);
      }
    }
    parent = null;
    returnPc = -1;
  }

  /// Only consulted after a native unwind. An inactive cached child has no
  /// return address; calls already set that address as part of their ABI.
  TypedFrame get activeFrame {
    var frame = this;
    while (true) {
      final child = frame._child;
      if (child == null || child.returnPc < 0) return frame;
      frame = child;
    }
  }

  List<Object?> environment = const [];
  final Int64List intSpills;
  final Float64List doubleSpills;
  final Uint8List boolSpills;
  final List<Object?> objectSpills, objectOutgoing;
}
