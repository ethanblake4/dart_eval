import 'dart:io';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:dart_eval/dart_eval.dart';
import 'workloads/int_sum.dart' as int_sum;
import 'workloads/double_math.dart' as double_math;
import 'workloads/int_mix.dart' as int_mix;
import 'workloads/particles.dart' as particles;
import 'workloads/checkout.dart' as checkout;
import 'workloads/events.dart' as events;
import 'workloads/word_count.dart' as word_count;
import 'workloads/recursive_tree.dart' as recursive_tree;
final natives=<String,num Function(int)>{'int_sum':int_sum.run,'double_math':double_math.run,'int_mix':int_mix.run,'particles':particles.run,'checkout':checkout.run,'events':events.run,'word_count':word_count.run,'recursive_tree':recursive_tree.run};
final dir=Directory('D:/Projects/dart_eval/.dart_tool/performance_optimization_20260916/experiments/inline_pools/probes');
const library='package:audit/main.dart';
Object? sink;
@pragma('vm:never-inline')
void consume(Object? value){sink=value;}
bool equal(num a,num b)=>a==b || (a-b).abs()<=math.max(a.abs(),b.abs())*1e-10;
Map<String,Object?> stats(String name,String mode,List<double> values,{Object? result,int? n,int? batch}) {
 final ordered=[...values]..sort();
 return {'case':name,'mode':mode,'n':n,'batch':batch,'median_ms':ordered[ordered.length~/2], 'min_ms':ordered.first,'max_ms':ordered.last,'samples_ms':values,'result':result};
}
void main(List<String> args){
 final cases=(jsonDecode(File('${dir.path}/cases.json').readAsStringSync()) as List).cast<Map>();
 if(args.first=='prepare'){
 for(final item in cases){final name=item['name'] as String;try{
 final compiler=Compiler();final sw=Stopwatch()..start();
 final p=compiler.compile({'audit':{'main.dart':item['source'] as String}});sw.stop();
 File('${dir.path}/$name.evc').writeAsBytesSync(p.write());
 final runtime=Runtime.ofProgram(p); final n=item['n'] as int;
 final actual=runtime.executeLib(library,'main',arguments:{'n':n}) as num;final expected=natives[name]!(n);
 if(!equal(actual,expected))throw StateError('$name mismatch $actual != $expected');
 final ir=StringBuffer();for(final entry in compiler.ssaFunctionGraphs.entries){ir.writeln('FUNCTION ${entry.key}: ${compiler.functionNames[entry.key]}');for(final id in entry.value.graph.vertices){final b=entry.value[id]!;ir.writeln('BLOCK $id: ${b.label}');for(final op in b.code){ir.writeln(op);}}}
 File('${dir.path}/$name.ir.txt').writeAsStringSync(ir.toString());
 final text=StringBuffer();final counts=<String,int>{};final code=p.typedProgram.code;final bytes=ByteData.sublistView(code);
 for(var pc=0;pc<code.length;){final op=TypedOp.instructions[code[pc]];counts[op.name]=(counts[op.name]??0)+1;
 final immediate=op.length==1?'':op.length==5?bytes.getUint32(pc+1,Endian.little):op.immediate==TypedImmediate.shortBranch?pc+3+bytes.getInt16(pc+1,Endian.little):op.immediate==TypedImmediate.integer?bytes.getInt16(pc+1,Endian.little):bytes.getUint16(pc+1,Endian.little);
 text.writeln('$pc ${op.name} $immediate');pc+=op.length;}
 File('${dir.path}/$name.bytecode.txt').writeAsStringSync(text.toString());
 print(jsonEncode({'case':name,'compile_ms':sw.elapsedMicroseconds/1000,'evc_bytes':p.write().length,'code_bytes':code.length,'functions':p.typedProgram.functions.length,'ops':counts,'checksum':actual,'native_checksum':expected}));
 }catch(e,st){print(jsonEncode({'case':name,'error':e.toString(),'stack':st.toString()}));}}
 return;}
 if(args.first=='execute'){
 final samples=args.length>1?int.parse(args[1]):7;
 for(final item in cases){final name=item['name'] as String;final file=File('${dir.path}/$name.evc');if(!file.existsSync())continue;
 final n=item['n'] as int;final native=natives[name]!; final runtime=Runtime(file.readAsBytesSync().buffer);final arguments={'n':n};
 num guest()=>runtime.executeLib(library,'main',arguments:arguments) as num;
 final expected=native(n); for(var warm=0;warm<5;warm++){sink=guest();sink=native(n);}
 final probe=Stopwatch()..start();for(var i=0;i<10;i++){sink=native(n);}probe.stop();
 final batch=math.max(1,math.min(10000,(30000/(probe.elapsedMicroseconds/10+1)).ceil()));
 final nativeTimes=<double>[],guestTimes=<double>[];
 for(var sample=0;sample<samples;sample++){
 for(final mode in sample.isEven?['native','eval']:['eval','native']){final count=mode=='native'?batch:1;num value=0;final sw=Stopwatch()..start();for(var k=0;k<count;k++){value=mode=='native'?native(n):guest();sink=value;}sw.stop();
 if(!equal(value,expected))throw StateError('$name mismatch $value $expected');(mode=='native'?nativeTimes:guestTimes).add(sw.elapsedMicroseconds/1000/count);}}
 print(jsonEncode(stats(name,'native_aot',nativeTimes,result:expected,n:n,batch:batch)));
 print(jsonEncode(stats(name,'eval_aot',guestTimes,result:expected,n:n,batch:1)));
 }return;}
 if(args.first=='loadprepare'){
 for(final count in [1,100,1000]){final source=StringBuffer('int main()=>42;');for(var i=0;i<count;i++){source.writeln('String f$i(int n, {String suffix="x"}) => "loading-constant-$i-abcdefghijklmnopqrstuvwxyz" + suffix + n.toString();');}
 final p=Compiler().compile({'audit':{'main.dart':source.toString()}});File('${dir.path}/load$count.evc').writeAsBytesSync(p.write());print(jsonEncode({'case':'load$count','evc_bytes':p.write().length,'code_bytes':p.typedProgram.code.length,'functions':p.typedProgram.functions.length,'exports':p.typedProgram.exports.length}));}return;}
 if(args.first=='branchprepare'){
 for(final count in [100,1000,3000]){final source=StringBuffer('int main()=>42;');for(var i=0;i<count;i++){source.writeln('int f$i(int n){var sum=$i;for(var j=0;j<n;j++){sum+=j;}return sum;}');}
 final p=Compiler().compile({'audit':{'main.dart':source.toString()}});File('${dir.path}/branch$count.evc').writeAsBytesSync(p.write());print(jsonEncode({'case':'branch$count','evc_bytes':p.write().length,'code_bytes':p.typedProgram.code.length,'functions':p.typedProgram.functions.length,'exports':p.typedProgram.exports.length}));}return;}
 if(args.first=='load'){
 for(final name in ['load1','load100','load1000','branch100','branch1000','branch3000']){final count=int.parse(name.replaceAll(RegExp(r'[^0-9]'),''));final file=File('${dir.path}/$name.evc');final bytes=file.readAsBytesSync();final parsed=Program.read(bytes.buffer);final typedBytes=parsed.typedProgram.write().buffer;
 final modes=<String,Object? Function()>{'file_read_warm_cache':()=>file.readAsBytesSync(),'runtime_ctor_lazy':()=>Runtime(bytes.buffer),'program_read_validate':()=>Program.read(bytes.buffer),'typed_payload_read_validate':()=>TypedProgram.read(typedBytes),'runtime_of_program':()=>Runtime.ofProgram(parsed),'first_call_from_bytes':()=>Runtime(bytes.buffer).executeLib(library,'main'),'first_call_from_program':()=>Runtime.ofProgram(parsed).executeLib(library,'main')};
 final batch=count>=3000?3:count>=1000?10:count==100?50:100;
 for(final entry in modes.entries){for(var warm=0;warm<8;warm++){consume(entry.value());}final times=<double>[];for(var sample=0;sample<7;sample++){final sw=Stopwatch()..start();for(var i=0;i<batch;i++){consume(entry.value());}sw.stop();times.add(sw.elapsedMicroseconds/1000/batch);}print(jsonEncode(stats(name,entry.key,times,batch:batch,result:sink is Runtime?(sink as Runtime).id:sink.runtimeType.toString())));}}
 }
}
