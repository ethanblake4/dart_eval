import 'dart:typed_data';
import 'package:dart_eval/dart_eval.dart';

void main() {
  final constant = TypedProgram(Uint8List.fromList([
    if (TypedOp.instructions[TypedOp.aConstant].extended) ...[
      TypedOp.extended, TypedOp.aConstant - TypedOp.extended - 1,
    ] else TypedOp.aConstant,
    0, 0, TypedOp.aReturn,
  ]), integers: [42]);
  for (final p in [constant, TypedProgram.read(constant.write().buffer)]) {
    if (TypedMachine.run(p) != 42) throw StateError('Extended constant');
  }
  final p = Compiler().compile({'probe': {'main.dart': '''
    int counter = 0;
    int mark(int n) {
      try {
        counter = counter + n;
        if (n < 0) throw 'negative';
        return counter;
      } catch (e) { return -99; }
      finally { counter = counter + 1; }
    }
    int main() {
      var sum = 0;
      for (var i = 0; i < 5; i++) sum += mark(i);
      sum += mark(-1);
      return sum + counter;
    }
  '''}});
  for (final runtime in [Runtime.ofProgram(p), Runtime(p.write().buffer)]) {
    final result = runtime.executeLib('package:probe/main.dart', 'main');
    if (result != -54) throw StateError('Extended globals/exceptions: $result');
  }
  for (final code in [[TypedOp.extended], [TypedOp.extended, 255]]) {
    try {
      TypedProgram(Uint8List.fromList(code));
      throw StateError('Invalid extended opcode accepted');
    } on FormatException { /* expected */ }
  }
  print('Extended constants, globals, exceptions, serialized execution and invalid encodings pass.');
}
