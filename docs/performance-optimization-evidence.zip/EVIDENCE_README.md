# Runtime optimization evidence

Extract this archive into dart_eval/.dart_tool/performance_optimization_20260916.
The tested SDK was Dart 3.10.7 on Windows x64. Timing processes used logical
CPU2, AboveNormal, one process at a time. ARM64 is static Linux cross-compilation,
not a hardware timing result. See the committed performance report for decisions.

Run `dart pub get` in the enclosing checkout to provide dependencies, then run
`python .dart_tool/performance_optimization_20260916/restore_packages.py`.
This resolves installed dependencies while pointing each variant at its archived
source and the archived control_flow_graph library. It also updates probe paths.
Identical source files are stored once in the reference tree; restoration copies
them into each variant before applying its existing changed files.
Use the included dependency lockfile and named SDK for closest reproduction.

From a variant directory, run `dart compile exe probes/audit.dart -o audit.exe`,
then `audit.exe prepare` and `audit.exe execute 15`. The final directory uses
`audit.dart` at its root. `benchmark/calls.dart` takes iterations and samples;
`benchmark/callbacks.dart` does likewise. Pin affinity/priority when comparing.
Preparation validates results against native implementations and emits bytecode
and IR. Extended variants also have `probes/extended_probe.dart` for cold opcode,
codec, global and exception checks. Payloads are variant-specific.

The source snapshots are authoritative. `runtime_variants.py` records how the
experiments were constructed, but rerunning its snapshot command would replace
the archived baseline with the enclosing checkout. `inspect_variants.py` records
the ARM path counting procedure and `disassemble_variants.py` records LLVM usage.
The counts follow default conditional fallthrough and exclude helper bodies;
they are not universal worst-case or hot-path counts for dynamic operations.

Original and final timing files, including noisy sweeps, remain included. Full
source snapshots, assembly listings, JSON samples, emitted programs, IR, validation
logs and the report are included. Executables, AOT images, ELF copies, package
caches and machine-specific package configs are excluded.
