# Register affinity evidence

Reference: dart_eval 7ee5a3e, CFG 9e96620, Dart 3.10.7. The ZIP stores one full
reference source tree and changed-file overlays for the other five variants.
Native executables, AOT images, dependency caches, and machine-specific package
configurations are omitted. Opcode tables and the no-X ABI differ. Never mix
payloads between variants or with production.

Extract into an empty directory. Run `python restore.py` with Dart 3.10.7 to
restore missing source files and resolve dependencies using the included lock
file. Alternatively pass the path to an existing compatible package_config.json.
That copies no cached dependencies and rewrites only local project URIs.

`python experiment.py build` rebuilds the original five variants and checks the
eight audit workloads. Add `no_x` as an explicit argument to build that variant.
`python experiment.py affinity reference e_only s_only s_choice combined no_x`
builds and checks the four new source workloads and boolean boundary cases.
The `prepare` action is only for constructing a new experiment from a workspace;
do not run it on restored evidence, where it would replace variant source.

Timing was sequential on Windows x64, pinned to logical CPU 2, affinity mask 4,
AboveNormal. `run.ps1` starts a hidden process with those settings. Examples:

```powershell
./run.ps1 -Variant no_x -Sweep 4 -Rotation 2 -Samples 21 -Warmup
./run.ps1 -Variant no_x -Sweep 2 -Samples 15 -Probe affinity -Warmup
```

Audit sweeps 1/2/3 used rotations 2/6/0 and 15 samples. They ran respectively in
reference/e_only/s_only/s_choice/combined/no_x order, reversed order, and
reference/no_x/e_only/combined/s_only/s_choice order. Affinity sweep 1 used the
first order; sweep 2 reversed it and added an untimed complete three-sample
process first. Audit sweep 4 adds the same warmup and uses 21 samples for the
reference/e_only/no_x finalists. Every sample checks its native checksum.
Raw startup-affected measurements are retained. `summarize.py` excludes the
first two audit cases per process from its exploratory aggregate, never from
raw logs. The report specifies which runs each final table uses.

`python experiment.py arm <variant>` cross-compiles the audit driver and uses
LLVM to disassemble the verified dispatch symbol range. Adjust the LLVM path in
experiment.py on another machine. `python inspect.py` reads all six disassemblies
and opcode jump tables. Its path counts follow default conditional fallthroughs
and exclude helper bodies. These are static ARM64 measurements, not ARM timings.

`python experiment.py trace <variants...>` builds separate instrumented audit
executables; `trace-affinity` does the same for the targeted source workloads.
Every dispatched opcode increments a counter. These binaries are never timed.
The saved trace JSON records all nonzero counts, including fresh and serialized
targeted executions at 257 iterations.

The combined and no_x validation logs record full 822-test passes with the
reference dependencies. Tests were invoked through the test package entrypoint
with an explicit package configuration to avoid implicit dependency resolution.
No-X changes four tests to reflect its different internal ABI. The other source
semantics tests remain unchanged. The no-X prototype retains an unused register
ID 5 constant/hole; there is no X local or operand handler in its dispatch.

`sha256.json` verifies every archived file. The source overlays, raw logs,
disassembly, counts, and scripts are the record; generated binaries can be
reconstructed.
