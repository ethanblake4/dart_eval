"""Apply the reviewed fusion pass to the reference and no-X snapshots."""
from pathlib import Path
import re, shutil
from experiment import OUT, BACKEND, GENERATOR, configure, read, write, replace, run

fused=OUT/'fused'
backend=read(fused/BACKEND)
start=backend.index('    // Fuse only adjacent pure comparisons')
end=backend.index('    for (var bank = 0; bank < 4; bank++) {',start)
fusion=backend[start:end]
generator=read(fused/GENERATOR)
start=generator.index('  // Branch on the negated comparison')
end=generator.index('  for (final op in [...ops]) {',start)
branch_ops=generator[start:end]
for name,base,hot in [('fused_hot','reference',True),('no_x_fused','no_x',False)]:
    project=OUT/name
    assert not project.exists(), 'Preserve existing measured variant'
    for folder in ['lib','tool','test','benchmark']:
        shutil.copytree(OUT/base/folder,project/folder)
    shutil.copy2(OUT/base/'pubspec.yaml',project/'pubspec.yaml')
    configure(project)
    source=read(project/BACKEND)
    source=replace(source,'      inputs.length == 1 &&','      otherTarget != null &&\n      inputs.isNotEmpty &&')
    anchor='    for (var bank = 0; bank < 4; bank++) {\n      graph.registerRegType('
    source=replace(source,anchor,fusion+anchor)
    write(project/BACKEND,source)
    ops=branch_ops
    if hot:
        ops=re.sub(r"for \(final comparison in \{.*?\}\.entries\)","for (final comparison in {'Lt': '<'}.entries)",ops,flags=re.S)
        ops=replace(ops,'[(0, 1), (2, 3)]','[(0, 1)]')
    write(project/GENERATOR,replace(read(project/GENERATOR),'  for (final op in [...ops]) {',ops+'  for (final op in [...ops]) {'))
    test=read(fused/'test/compiler/fused_branch_test.dart')
    if hot:
        test=replace(test,"        expect(\n          names(program),\n          contains('jumpNot$suffix${type == 'int' ? 'AB' : 'FG'}Short'),\n        );", "        if (type == 'int' && suffix == 'Lt') {\n          expect(names(program), contains('jumpNotLtABShort'));\n        }")
        test=replace(test,'greaterThanOrEqualTo(3)','greaterThanOrEqualTo(2)')
    write(project/'test/compiler/fused_branch_test.dart',test)
    probe=project/'probes'
    shutil.copytree(OUT/'reference/probes/workloads',probe/'workloads')
    shutil.copy2(OUT/'reference/probes/cases.json',probe/'cases.json')
    shutil.copy2(OUT/'probes/affinity.dart',probe/'affinity.dart')
    audit=read(OUT/'reference/probes/audit.dart')
    audit=re.sub(r"final dir=Directory\('[^']*'\);",f"final dir=Directory('{probe.as_posix()}');",audit)
    write(probe/'audit.dart',audit)
    run(['dart','tool/generate_typed_machine.dart'],project,project/'generate.txt')
    print('prepared',name)
