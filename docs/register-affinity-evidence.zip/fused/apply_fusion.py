"""Apply the isolated fusion experiment to an existing sibling snapshot.

Usage: python fused/apply_fusion.py no_x_fused [LtAB]
The destination must already contain a snapshot. Regenerate its machine after.
"""
from pathlib import Path
import sys

here = Path(__file__).resolve().parent
destination = (here.parent / sys.argv[1]).resolve()
assert destination.parent == here.parent.resolve() and destination != here
backend = Path('lib/src/eval/compiler/backend/typed_backend.dart')
generator = Path('tool/generate_typed_machine.dart')
source = (here / backend).read_text(encoding='utf-8')
start = source.index('    // Fuse only adjacent pure comparisons')
end = source.index('    for (var bank = 0; bank < 4; bank++) {', start)
fusion = source[start:end]
path = destination / backend
text = path.read_text(encoding='utf-8')
assert '// Fuse only adjacent pure comparisons' not in text
text = text.replace('      inputs.length == 1 &&',
                    '      otherTarget != null &&\n      inputs.isNotEmpty &&')
marker = '    for (var bank = 0; bank < 4; bank++) {'
position = text.rindex(marker)
path.write_text(text[:position] + fusion + text[position:], encoding='utf-8')
source = (here / generator).read_text(encoding='utf-8')
start = source.index('  // Branch on the negated comparison')
end = source.index('  for (final op in [...ops]) {', start)
new_ops = source[start:end]
if len(sys.argv) > 2:
    suffix = sys.argv[2]
    assert suffix == 'LtAB'
    new_ops += "  ops.removeWhere((op) => op.name.startsWith('jumpNot') && op.name != 'jumpNotLtAB');\n"
path = destination / generator
text = path.read_text(encoding='utf-8')
assert '// Branch on the negated comparison' not in text
marker = '  for (final op in [...ops]) {'
assert marker in text
path.write_text(text.replace(marker, new_ops + marker), encoding='utf-8')
