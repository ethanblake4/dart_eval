import 'dart:convert';

import 'package:dart_eval/dart_eval.dart';
import 'package:dart_eval/dart_eval_bridge.dart';
import 'package:dart_eval/stdlib/core.dart';

const _library = 'package:register_affinity/main.dart';
const _workloads = ['fields', 'maps', 'booleans', 'comparisons'];
const _source = r'''
  class FieldState {
    int value = 3;
    int step = 5;
    int mirror = 7;
    bool forward = true;
  }

  int fields(int n) {
    final state = FieldState();
    var checksum = 0;
    for (var i = 0; i < n; i = i + 1) {
      final receiver = state;
      final before = receiver.value;
      receiver.value = (before + receiver.step + i % 7) % 1000003;
      if (receiver.forward) {
        receiver.mirror = (receiver.mirror + receiver.value) % 1000033;
      } else {
        receiver.step = (receiver.step + receiver.mirror + 3) % 997;
      }
      receiver.forward = !receiver.forward;
      checksum = (checksum + receiver.value + receiver.mirror +
          (receiver.forward ? 1 : 0)) % 2147483647;
    }
    return (checksum + state.value + state.step + state.mirror).toInt();
  }

  int maps(int n) {
    final values = <int, int>{};
    var checksum = 0;
    for (var i = 0; i < n; i = i + 1) {
      final key = i % 97;
      final previous = values[key] ?? 0;
      final next = (previous + i % 13 + 1) % 1000003;
      values[key] = next;
      if (i % 11 == 0) {
        final other = values[(key + 31) % 97];
        if (other != null) checksum = (checksum + other) % 2147483647;
      }
      if (i % 17 == 0) values.remove((key + 53) % 97);
      checksum = (checksum + (values.containsKey(key) ? values[key] ?? 0 : 0)) %
          2147483647;
    }
    for (final key in values.keys) {
      checksum = (checksum + key) % 2147483647;
    }
    for (final value in values.values) {
      checksum = (checksum + value) % 2147483647;
    }
    return (checksum + values.length).toInt();
  }

  class BoolState {
    int effects = 0;
    bool touch(bool value) {
      effects = effects + 1;
      return value;
    }
  }

  bool combine(bool a, bool b, bool c, bool d) =>
      (a && b) || (c && !d) || (a == d);

  bool boolEntry(bool a, bool b, bool c, bool d) => combine(a, b, c, d);

  Function boolCallback() =>
      (bool a, bool b, bool c, bool d) => combine(a, b, c, d);

  int booleans(int n) {
    final state = BoolState();
    var checksum = 0;
    for (var i = 0; i < n; i = i + 1) {
      final a = i % 2 == 0;
      final b = i % 3 == 0;
      final c = i % 5 < 2;
      final d = i % 7 == 0;
      final result = (a && state.touch(b)) ||
          (c && state.touch(d)) ||
          state.touch(a == d);
      final accepted = combine(result, b, c, d);
      if (accepted) checksum = (checksum + i % 101 + 1) % 2147483647;
      if (result != accepted) checksum = (checksum + 17) % 2147483647;
    }
    return (checksum + state.effects).toInt();
  }

  bool compare(double a, double b, double c, double nan) {
    final rising = a < b && b <= c;
    final falling = a > b && b >= c;
    final edge = a == c || a != b;
    final unordered = !(nan < a) && !(nan >= b) && nan != nan;
    return (rising || falling) && edge && unordered;
  }

  int comparisons(int n) {
    final nan = double.nan;
    var checksum = 0;
    for (var i = 0; i < n; i = i + 1) {
      final a = (i % 101) * 0.5;
      final b = (i % 67) * 0.75;
      final c = (i % 43) * 1.25;
      final low = i % 19;
      final high = i % 23;
      final nested = low < high && (high <= 17 || low == i % 11);
      if ((nested && compare(a, b, c, nan)) ||
          (!nested && (a >= c || nan != nan))) {
        checksum = (checksum + i % 127 + 1) % 2147483647;
      }
    }
    return checksum.toInt();
  }
''';

int _nativeFields(int n) {
  final state = _NativeFieldState();
  var checksum = 0;
  for (var i = 0; i < n; i++) {
    final receiver = state;
    final before = receiver.value;
    receiver.value = (before + receiver.step + i % 7) % 1000003;
    if (receiver.forward) {
      receiver.mirror = (receiver.mirror + receiver.value) % 1000033;
    } else {
      receiver.step = (receiver.step + receiver.mirror + 3) % 997;
    }
    receiver.forward = !receiver.forward;
    checksum =
        (checksum +
            receiver.value +
            receiver.mirror +
            (receiver.forward ? 1 : 0)) %
        2147483647;
  }
  return checksum + state.value + state.step + state.mirror;
}

final class _NativeFieldState {
  int value = 3;
  int step = 5;
  int mirror = 7;
  bool forward = true;
}

int _nativeMaps(int n) {
  final values = <int, int>{};
  var checksum = 0;
  for (var i = 0; i < n; i++) {
    final key = i % 97;
    final previous = values[key] ?? 0;
    final next = (previous + i % 13 + 1) % 1000003;
    values[key] = next;
    if (i % 11 == 0) {
      final other = values[(key + 31) % 97];
      if (other != null) checksum = (checksum + other) % 2147483647;
    }
    if (i % 17 == 0) values.remove((key + 53) % 97);
    checksum =
        (checksum + (values.containsKey(key) ? values[key] ?? 0 : 0)) %
        2147483647;
  }
  for (final key in values.keys) {
    checksum = (checksum + key) % 2147483647;
  }
  for (final value in values.values) {
    checksum = (checksum + value) % 2147483647;
  }
  return checksum + values.length;
}

final class _NativeBoolState {
  int effects = 0;
  bool touch(bool value) {
    effects++;
    return value;
  }
}

bool _nativeCombine(bool a, bool b, bool c, bool d) =>
    (a && b) || (c && !d) || (a == d);

int _nativeBooleans(int n) {
  final state = _NativeBoolState();
  var checksum = 0;
  for (var i = 0; i < n; i++) {
    final a = i % 2 == 0;
    final b = i % 3 == 0;
    final c = i % 5 < 2;
    final d = i % 7 == 0;
    final result =
        (a && state.touch(b)) || (c && state.touch(d)) || state.touch(a == d);
    final accepted = _nativeCombine(result, b, c, d);
    if (accepted) checksum = (checksum + i % 101 + 1) % 2147483647;
    if (result != accepted) checksum = (checksum + 17) % 2147483647;
  }
  return checksum + state.effects;
}

bool _nativeCompare(double a, double b, double c, double nan) {
  final rising = a < b && b <= c;
  final falling = a > b && b >= c;
  final edge = a == c || a != b;
  final unordered = !(nan < a) && !(nan >= b) && nan != nan;
  return (rising || falling) && edge && unordered;
}

int _nativeComparisons(int n) {
  final nan = double.nan;
  var checksum = 0;
  for (var i = 0; i < n; i++) {
    final a = (i % 101) * 0.5;
    final b = (i % 67) * 0.75;
    final c = (i % 43) * 1.25;
    final low = i % 19;
    final high = i % 23;
    final nested = low < high && (high <= 17 || low == i % 11);
    if ((nested && _nativeCompare(a, b, c, nan)) ||
        (!nested && (a >= c || nan != nan))) {
      checksum = (checksum + i % 127 + 1) % 2147483647;
    }
  }
  return checksum;
}

final _native = <String, int Function(int)>{
  'fields': _nativeFields,
  'maps': _nativeMaps,
  'booleans': _nativeBooleans,
  'comparisons': _nativeComparisons,
};

final class _ResolvedRuntime {
  _ResolvedRuntime(this.name, this.runtime, Map<String, int> functionIds)
    : _functionIds = functionIds;

  final String name;
  final Runtime runtime;
  final Map<String, int> _functionIds;

  int call(String workload, List<Object?> arguments) =>
      runtime.execute(_functionIds[workload]!, arguments: arguments) as int;
}

final class _Probe {
  _Probe() {
    final compiler = Compiler();
    program = compiler.compile({
      'register_affinity': {'main.dart': _source},
    });
    final functionIds = {
      for (final export in program.typedProgram.exports)
        if (export.library == _library && _workloads.contains(export.name))
          export.name: export.functionId,
    };
    if (functionIds.length != _workloads.length) {
      throw StateError('Could not resolve all workloads: $functionIds');
    }
    final bytes = program.write().buffer;
    runtimes = [
      _ResolvedRuntime('fresh', Runtime.ofProgram(program), functionIds),
      _ResolvedRuntime('serialized', Runtime(bytes), functionIds),
    ];
  }

  late final Program program;
  late final List<_ResolvedRuntime> runtimes;

  Map<String, int> check(int iterations) {
    final arguments = <Object?>[iterations];
    final checksums = <String, int>{};
    for (final workload in _workloads) {
      final expected = _native[workload]!(iterations);
      checksums[workload] = expected;
      for (final resolved in runtimes) {
        final actual = resolved.call(workload, arguments);
        if (actual != expected) {
          throw StateError('$workload ${resolved.name}: $actual != $expected');
        }
      }
    }
    _checkBooleanBoundaries();
    return checksums;
  }

  void _checkBooleanBoundaries() {
    const cases = [
      (true, true, false, false),
      (false, false, true, false),
      (false, true, false, true),
    ];
    for (final resolved in runtimes) {
      final callback =
          resolved.runtime.executeLib(_library, 'boolCallback') as EvalCallable;
      for (final (a, b, c, d) in cases) {
        final expected = _nativeCombine(a, b, c, d);
        final entry = resolved.runtime.executeLib(
          _library,
          'boolEntry',
          arguments: {'d': d, 'b': b, 'a': a, 'c': c},
        );
        if (entry != expected) {
          throw StateError('boolEntry ${resolved.name}: $entry != $expected');
        }
        final closure = callback.call(resolved.runtime, null, [
          $bool(a),
          $bool(b),
          $bool(c),
          $bool(d),
        ]);
        final actual = (closure as $bool).$value;
        if (actual != expected) {
          throw StateError(
            'boolCallback ${resolved.name}: $actual != $expected',
          );
        }
      }
    }
  }
}

Map<String, Object?> _stats(
  String workload,
  String mode,
  int iterations,
  int batch,
  int checksum,
  List<double> samples,
) {
  final ordered = [...samples]..sort();
  return {
    'workload': workload,
    'mode': mode,
    'iterations': iterations,
    'batch': batch,
    'checksum': checksum,
    'median_ms': ordered[ordered.length ~/ 2],
    'min_ms': ordered.first,
    'max_ms': ordered.last,
    'samples_ms': samples,
  };
}

void _benchmark(_Probe probe, int iterations, int sampleCount) {
  final arguments = <Object?>[iterations];
  for (final workload in _workloads) {
    final expected = _native[workload]!(iterations);
    final calls = <String, int Function()>{
      'native': () => _native[workload]!(iterations),
      for (final resolved in probe.runtimes)
        resolved.name: () => resolved.call(workload, arguments),
    };
    const batches = {'native': 5, 'fresh': 1, 'serialized': 1};
    for (final entry in calls.entries) {
      for (var warmup = 0; warmup < 4; warmup++) {
        final value = entry.value();
        if (value != expected) {
          throw StateError('$workload ${entry.key} warmup mismatch');
        }
      }
    }

    final samples = {for (final mode in calls.keys) mode: <double>[]};
    final modes = calls.keys.toList(growable: false);
    for (var sample = 0; sample < sampleCount; sample++) {
      for (var offset = 0; offset < modes.length; offset++) {
        final mode = modes[(sample + offset) % modes.length];
        final batch = batches[mode]!;
        var checksum = 0;
        final call = calls[mode]!;
        final watch = Stopwatch()..start();
        for (var invocation = 0; invocation < batch; invocation++) {
          checksum += call();
        }
        watch.stop();
        if (checksum != expected * batch) {
          throw StateError(
            '$workload $mode measured checksum $checksum != ${expected * batch}',
          );
        }
        samples[mode]!.add(watch.elapsedMicroseconds / 1000 / batch);
      }
    }
    for (final mode in modes) {
      print(
        jsonEncode(
          _stats(
            workload,
            mode,
            iterations,
            batches[mode]!,
            expected,
            samples[mode]!,
          ),
        ),
      );
    }
  }
}

void main(List<String> arguments) {
  final mode = arguments.isEmpty ? 'check' : arguments[0];
  final probe = _Probe();
  if (mode == 'check') {
    final iterations = arguments.length > 1 ? int.parse(arguments[1]) : 257;
    print(
      jsonEncode({
        'mode': 'check',
        'iterations': iterations,
        'checksums': probe.check(iterations),
      }),
    );
    return;
  }
  if (mode == 'benchmark') {
    final iterations = arguments.length > 1 ? int.parse(arguments[1]) : 100000;
    final samples = arguments.length > 2 ? int.parse(arguments[2]) : 9;
    if (iterations < 1 || samples < 1) {
      throw ArgumentError('Iterations and samples must be positive');
    }
    probe.check(257);
    _benchmark(probe, iterations, samples);
    return;
  }
  throw ArgumentError(
    'Use check [iterations] or benchmark [iterations] [samples]',
  );
}
