int run(int n){final lines=<String>[]; for(var j=0;j<32;j++){lines.add('Alpha beta alpha gamma delta beta');}
 var checksum=0; for(var i=0;i<n;i++){final counts=<String,int>{}; for(var j=0;j<lines.length;j++){
 final words=lines[j].toLowerCase().split(' '); for(var k=0;k<words.length;k++){final word=words[k];counts[word]=(counts[word]??0)+1;}}
 checksum+=(counts['alpha']??0)+(counts['beta']??0)+counts.length;} return checksum; }