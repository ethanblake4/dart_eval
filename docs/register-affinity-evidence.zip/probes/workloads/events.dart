int run(int n){var state=0; final listeners=<void Function(int)>[];
 listeners.add((int value){state+=value;}); listeners.add((int value){state^=value*3;});
 for(var i=0;i<n;i++){for(var j=0;j<listeners.length;j++){listeners[j](i&255);}} return state;}