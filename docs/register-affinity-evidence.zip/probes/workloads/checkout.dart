class Line {final int price; final int quantity; Line(this.price,this.quantity); int total()=>price*quantity;}
class Rate {int apply(int total)=>total-total~/10;}
class Voucher {int apply(int total)=>total>1000?total-100:total;}
int run(int n){ final lines=<Line>[]; for(var j=0;j<16;j++){lines.add(Line(100+j*17,1+j%3));}
 final first=Rate(); final second=Voucher(); var result=0;
 for(var i=0;i<n;i++){var subtotal=0; for(var j=0;j<lines.length;j++){subtotal+=lines[j].total();} dynamic rule=first; if(i%2!=0){rule=second;} result+=rule.apply(subtotal) as int;}
 return result; }