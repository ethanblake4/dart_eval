class Node {final int value; final Node? left; final Node? right; Node(this.value,this.left,this.right);
 int sum(){var result=value; if(left!=null){result+=left!.sum();} if(right!=null){result+=right!.sum();}return result;}}
Node tree(int depth){if(depth==0){return Node(1,null,null);}return Node(depth,tree(depth-1),tree(depth-1));}
int run(int n){final root=tree(7);var sum=0;for(var i=0;i<n;i++){sum+=root.sum();}return sum;}