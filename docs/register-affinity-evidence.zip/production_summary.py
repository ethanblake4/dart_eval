from pathlib import Path
import json

root = Path(__file__).resolve().parent
result = {}
for probe, mode, key in [('audit', 'eval_aot', 'case'), ('affinity', 'fresh', 'workload')]:
    result[probe] = {}
    for variant in ['reference', 'no_x_fused', 'production']:
        for sweep in [10, 11]:
            for line in (root / variant / f'{probe}-sweep{sweep}.jsonl').read_text().splitlines():
                row = json.loads(line)
                if row['mode'] == mode:
                    result[probe].setdefault(row[key], {}).setdefault(variant, []).append(row['median_ms'])
    print(probe)
    for case, variants in result[probe].items():
        print(case, ' | '.join(name + ' ' + '/'.join(f'{x:.3f}' for x in values) for name, values in variants.items()))
(root / 'production/summary.json').write_text(json.dumps(result, indent=2))

for variant in ['reference', 'no_x_fused', 'production']:
    for probe in ['audit', 'affinity']:
        path = root / 'traces' / variant / f'{probe}-counts.jsonl'
        if not path.exists(): continue
        print('dispatches', variant, probe)
        for line in path.read_text().splitlines():
            row = json.loads(line)
            if row.get('mode') == 'serialized': continue
            if 'executed' in row:
                print(row['case'], sum(row['executed'].values()))
