from pathlib import Path
import hashlib, json, zipfile

root=Path(__file__).resolve().parent
repo=root.parents[1]
destination=repo/'docs/register-affinity-evidence.zip'
entries={}
def add(path, name=None):
    if path.is_file(): entries[name or path.relative_to(root).as_posix()]=path
add(repo/'docs/register-affinity-experiments-2026-09-16.md','report.md')
for name in ['experiment.py','fusion_variants.py','inspect.py','run.ps1','summarize.py','restore.py','bundle.py','README.md','summary.json','arm64-comparison.json','reference-head.txt','control_flow_graph-head.txt']:
    add(root/name)
for directory in ['lib','tool','benchmark','test']:
    for path in (root/'reference'/directory).rglob('*'): add(path)
for path in (root/'control_flow_graph/lib').rglob('*'): add(path)
add(root/'control_flow_graph/pubspec.yaml')
add(root/'reference/pubspec.yaml')
add(repo/'pubspec.lock','reference/pubspec.lock')
for path in (root/'reference/probes/workloads').rglob('*'):
    add(path,'probes/workloads/'+path.relative_to(root/'reference/probes/workloads').as_posix())
add(root/'reference/probes/cases.json','probes/cases.json')
add(root/'reference/probes/audit.dart','probes/audit.dart')
add(root/'probes/affinity.dart')
add(root/'fused/apply_fusion.py')
for name in ['reference','e_only','s_only','s_choice','combined','no_x','fused','fused_hot','no_x_fused','fused_hot_not','no_x_fused_not']:
    project=root/name
    if name!='reference':
        for directory in ['lib','tool','benchmark','test']:
            for path in (project/directory).rglob('*'):
                if not path.is_file(): continue
                base=root/'reference'/path.relative_to(project)
                if not base.exists() or path.read_bytes()!=base.read_bytes(): add(path)
    for path in project.iterdir():
        if path.suffix in ['.json','.jsonl','.txt','.log','.stderr','.patch']: add(path)
    for path in (project/'probes').glob('*'):
        if path.suffix in ['.txt','.evc']: add(path)
    trace=root/'traces'/name
    if trace.exists():
        for path in trace.glob('*-counts.jsonl'): add(path)
manifest={name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in entries.items()}
with zipfile.ZipFile(destination,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,path in sorted(entries.items()): archive.write(path,name)
    archive.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(destination) as archive:
    assert archive.testzip() is None
print(destination,len(entries)+1,destination.stat().st_size)
