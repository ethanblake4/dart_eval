"""Isolated register-affinity experiments, based on the recorded checkout."""
from pathlib import Path
from urllib.parse import urljoin
import json, shutil, subprocess, sys, re

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
OLD = ROOT / '.dart_tool/performance_optimization_20260916'
BACKEND = Path('lib/src/eval/compiler/backend/typed_backend.dart')
GENERATOR = Path('tool/generate_typed_machine.dart')
VARIANTS = ['reference', 'e_only', 's_only', 's_choice', 'combined']

def read(path): return path.read_text(encoding='utf-8')
def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value, encoding='utf-8')
def replace(source, old, new):
    assert old in source, old
    return source.replace(old, new)
def run(command, cwd, output):
    result = subprocess.run(command, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    write(output, result.stdout)
    if result.returncode: raise RuntimeError(f'{command}: {result.stdout}')

def configure(project):
    config_path = OUT / 'reference/.dart_tool/package_config.json'
    if not config_path.exists(): config_path = ROOT / '.dart_tool/package_config.json'
    config = json.loads(read(config_path))
    for package in config['packages']:
        package['rootUri'] = urljoin(config_path.as_uri(), package['rootUri'])
        if package['name'] == 'dart_eval': package['rootUri'] = project.as_uri() + '/'
        if package['name'] == 'control_flow_graph': package['rootUri'] = (OUT / 'control_flow_graph').as_uri() + '/'
    write(project / '.dart_tool/package_config.json', json.dumps(config, indent=2))

def prepare():
    for name, source in [('reference', ROOT), ('control_flow_graph', ROOT.parent/'control_flow_graph')]:
        project = OUT / name
        if project.exists(): continue
        for directory in (['lib', 'tool', 'benchmark', 'test'] if name == 'reference' else ['lib']):
            shutil.copytree(source / directory, project / directory)
        shutil.copy2(source/'pubspec.yaml', project/'pubspec.yaml')
        write(OUT/f'{name}-head.txt', subprocess.check_output(['git','rev-parse','HEAD'], cwd=source, text=True))
    for name in VARIANTS:
        project = OUT / name
        if name != 'reference':
            for directory in ['lib', 'tool', 'benchmark', 'test']:
                shutil.copytree(OUT/'reference'/directory, project/directory, dirs_exist_ok=True)
            shutil.copy2(OUT/'reference/pubspec.yaml', project/'pubspec.yaml')
        configure(project)
        probe = project/'probes'
        shutil.copytree(OLD/'workloads', probe/'workloads', dirs_exist_ok=True)
        shutil.copy2(OLD/'cases.json', probe/'cases.json')
        audit = replace(read(OLD/'audit.dart'), "Directory('.dart_tool/performance_optimization_20260916')", f"Directory('{probe.as_posix()}')")
        # Rotate case order between sweeps to expose startup/frequency effects.
        audit = replace(audit, 'for(final item in cases){final name=item[\'name\'] as String;final file=', "final rotation=args.length>2?int.parse(args[2])%cases.length:0; final ordered=[...cases.skip(rotation),...cases.take(rotation)];\n for(final item in ordered){final name=item['name'] as String;final file=")
        write(probe/'audit.dart', audit)
        generator, backend = read(project/GENERATOR), read(project/BACKEND)
        if name in ['e_only','combined']:
            generator = replace(generator, '  final originalOrder = ', "  ops.removeWhere((op) => RegExp(r'^x(Eq|Ne|Lt|Lte|Gt|Gte)(AB|FG)$').hasMatch(op.name));\n  final originalOrder = ")
            backend = replace(backend, "for (final flag in ['e', 'x'])\n          for (final order in integer", "for (final flag in ['e'])\n          for (final order in integer")
            backend = replace(backend, "for (final flag in ['e', 'x'])\n            for (final order in ['AB'])", "for (final flag in ['e'])\n            for (final order in ['AB'])")
        if name in ['s_only','s_choice','combined']:
            old = "  add(\n    'rLoadPropertyR',\n    'r = (r as TypedInstance).values[index];',\n    inputs: [6],\n    output: 6,\n    immediate: 'field',\n    mayThrow: true,\n  );"
            new = old.replace('rLoadPropertyR','rLoadPropertyS').replace('(r as TypedInstance)', '(s as TypedInstance)').replace('inputs: [6]', 'inputs: [7]')
            generator = replace(generator, old, new if name=='s_only' else old+'\n'+new)
            choice = "[isLate ? 'rLoadLatePropertyR' : 'rLoadPropertyS']" if name=='s_only' else "[if (isLate) 'rLoadLatePropertyR' else ...['rLoadPropertyR', 'rLoadPropertyS']]"
            backend = replace(backend, "[isLate ? 'rLoadLatePropertyR' : 'rLoadPropertyR']", choice)
        write(project/GENERATOR, generator)
        write(project/BACKEND, backend)
        run(['dart','tool/generate_typed_machine.dart'],project,project/'generate.txt')
        print('prepared',name,flush=True)

def build(names):
    for name in names:
        project=OUT/name
        if name in ['e_only','combined']:
            backend=read(project/BACKEND).replace("for (final flag in ['e', 'x'])\n            for (final order in ['AB'])", "for (final flag in ['e'])\n            for (final order in ['AB'])")
            write(project/BACKEND,backend)
        run(['dart','compile','exe','probes/audit.dart','-o','audit.exe'], project, project/'build.txt')
        run([str(project/'audit.exe'),'prepare'],project,project/'prepare.jsonl')
        rows=[json.loads(line) for line in read(project/'prepare.jsonl').splitlines()]
        assert len(rows)==8 and all('error' not in row for row in rows), rows
        print('built and checked',name,flush=True)

def affinity(names):
    for name in names:
        project=OUT/name
        shutil.copy2(OUT/'probes/affinity.dart',project/'probes/affinity.dart')
        run(['dart','compile','exe','probes/affinity.dart','-o','affinity.exe'],project,project/'affinity-build.txt')
        run([str(project/'affinity.exe'),'check'],project,project/'affinity-check.jsonl')
        print('affinity checked',name,flush=True)

def trace(names, probe='audit'):
    for name in names:
        project=OUT/'traces'/name
        shutil.copytree(OUT/name/'lib',project/'lib',dirs_exist_ok=True)
        shutil.copytree(OUT/name/'probes',project/'probes',dirs_exist_ok=True)
        configure(project)
        machine=project/'lib/src/eval/runtime/typed/typed_machine.g.dart'
        source=replace(read(machine), 'abstract final class TypedMachine {', 'abstract final class TypedMachine {\n  static final counts = List<int>.filled(TypedOp.instructions.length, 0);')
        source=replace(source,'switch (code[pc++]) {','counts[code[pc]]++;\n      switch (code[pc++]) {')
        write(machine,source)
        audit=read(project/f'probes/{probe}.dart')
        audit="import 'package:dart_eval/src/eval/runtime/typed/typed_machine.g.dart';\n"+audit
        counts="{for(var i=0;i<TypedMachine.counts.length;i++) if(TypedMachine.counts[i]!=0) TypedOp.instructions[i].name:TypedMachine.counts[i]}"
        if probe=='audit':
            audit=replace(audit, f"Directory('{(OUT/name/'probes').as_posix()}')", f"Directory('{(project/'probes').as_posix()}')")
            audit=replace(audit,'final actual=runtime.executeLib', 'TypedMachine.counts.fillRange(0, TypedMachine.counts.length, 0); final actual=runtime.executeLib')
            audit=replace(audit,"'ops':counts,", "'ops':counts,'executed':"+counts+",")
        else:
            audit=replace(audit,'final actual = resolved.call(workload, arguments);', "TypedMachine.counts.fillRange(0, TypedMachine.counts.length, 0); final actual = resolved.call(workload, arguments);\n print(jsonEncode({'case':workload,'mode':resolved.name,'executed':"+counts+"}));")
        write(project/f'probes/{probe}.dart',audit)
        run(['dart','compile','exe',f'probes/{probe}.dart','-o',f'{probe}-trace.exe'],project,project/f'{probe}-build.txt')
        run([str(project/f'{probe}-trace.exe'),'prepare' if probe=='audit' else 'check'],project,project/f'{probe}-counts.jsonl')
        rows=[json.loads(line) for line in read(project/f'{probe}-counts.jsonl').splitlines()]
        assert all('error' not in row for row in rows),rows
        print('traced',name,flush=True)

def arm(names):
    llvm=Path('C:/Program Files/LLVM/bin')
    for name in names:
        project=OUT/name
        run(['dart','compile','aot-snapshot','--target-os=linux','--target-arch=arm64','probes/audit.dart','-o','runtime.aot'],project,project/'arm-build.txt')
        symbols=subprocess.check_output([llvm/'llvm-objdump.exe','--syms',project/'runtime.aot'],text=True)
        write(project/'symbols.txt',symbols)
        match=re.search(r'^([0-9a-f]+)\s+.*\.text\s+([0-9a-f]+)\s+TypedMachine\._dispatch$',symbols,re.M)
        start,size=(int(v,16) for v in match.groups())
        subprocess.run([llvm/'llvm-objcopy.exe','--strip-all',project/'runtime.aot',project/'inspection.elf'],check=True)
        output=subprocess.check_output([llvm/'llvm-objdump.exe','--disassemble-all','--triple=aarch64',f'--start-address=0x{start:x}',f'--stop-address=0x{start+size:x}','--no-show-raw-insn',project/'inspection.elf'],text=True)
        write(project/'dispatch.txt',output)
        print(name,size,flush=True)

if __name__=='__main__':
    action=sys.argv[1]; names=sys.argv[2:] or VARIANTS
    if action=='prepare': prepare()
    elif action=='build': build(names)
    elif action=='arm': arm(names)
    elif action=='affinity': affinity(names)
    elif action=='trace': trace(names)
    elif action=='trace-affinity': trace(names,'affinity')
