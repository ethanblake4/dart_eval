import 'dart:convert';

import 'package:dart_eval/dart_eval.dart';

const library = 'package:selection/main.dart';

void main() {
  final cases = <String, String>{
    'int_call_permutation': r'''
      int callee(int left, int right) => left - right;
      int main(int a, int b) => callee(b, a);
    ''',
    'double_call_permutation': r'''
      double callee(double left, double right) => left - right;
      double main(double a, double b) => callee(b, a);
    ''',
    'bool_call_permutation': r'''
      bool callee(bool left, bool right) => left && !right;
      bool main(bool a, bool b) => callee(b, a);
    ''',
    'int_free_target_copy': r'''
      int callee(int value) => value + 1;
      int main(int a, int b) => callee(b);
    ''',
    'double_free_target_copy': r'''
      double callee(double value) => value + 1.0;
      double main(double a, double b) => callee(b);
    ''',
    'phi_permutation': r'''
      int main(int a, int b, bool reverse) {
        var left = a;
        var right = b;
        if (reverse) {
          final old = left;
          left = right;
          right = old;
        }
        return left - right;
      }
    ''',
  };
  for (final entry in cases.entries) {
    final program = Compiler().compile({
      'selection': {'main.dart': entry.value},
    });
    final counts = <String, int>{};
    final code = program.typedProgram.code;
    for (var pc = 0; pc < code.length;) {
      final instruction = TypedOp.instructions[code[pc]];
      counts[instruction.name] = (counts[instruction.name] ?? 0) + 1;
      pc += instruction.length;
    }
    final selected = {
      for (final item in counts.entries)
        if (item.key.contains('From') ||
            item.key.contains('Swap') ||
            item.key.contains('Spill') ||
            item.key.contains('Reload'))
          item.key: item.value,
    };
    print(jsonEncode({'case': entry.key, 'selected': selected}));
  }
}
