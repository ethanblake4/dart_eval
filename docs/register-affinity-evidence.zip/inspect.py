from pathlib import Path
import json, re, struct, sys
root=Path(__file__).resolve().parent
rows=[]
for name in sys.argv[1:] or ['reference','e_only','s_only','s_choice','combined','no_x']:
    path=root/name
    asm={int(a,16):(op,arg) for a,op,arg in re.findall(r'^[ \t]*([0-9a-f]+):[ \t]+(\S+)[ \t]*(.*?)$',(path/'dispatch.txt').read_text(),re.M)}
    syms={int(a,16):n for a,n in re.findall(r'^([0-9a-f]+)\s+.*?\.text\s+[0-9a-f]+\s+(.+)$',(path/'symbols.txt').read_text(),re.M)}
    start=next(a for a,n in syms.items() if n=='TypedMachine._dispatch')
    branch=next(a for a,(op,_) in asm.items() if op=='br')
    def target(arg):
        hits=re.findall(r'0x([a-f0-9]+)',arg.split('<')[0])
        return int(hits[-1],16) if hits else None
    header=min(target(arg) for a,(op,arg) in asm.items() if op=='b' and start+64<target(arg)<branch and a>branch)
    # The first two handlers are eTrue/eFalse in every variant. The third may
    # be an object move after removing x, so use only verified first two starts.
    first=branch+4
    pc=first
    while asm[pc][0]!='b': pc+=4
    second=pc+4
    blob=(path/'runtime.aot').read_bytes()
    pattern=struct.pack('<ii',first-start,second-start)
    locations=[m.start() for m in re.finditer(re.escape(pattern),blob)]
    assert len(locations)==1,(name,locations)
    names=re.findall(r'^  static const (\w+) = \d+;',(path/'lib/src/eval/runtime/typed/typed_ops.g.dart').read_text(),re.M)
    offsets=struct.unpack_from('<'+'i'*len(names),blob,locations[0])
    addresses={n:start+v for n,v in zip(names,offsets)}
    assert all(a in asm for a in addresses.values())
    paths={}
    for opname in ['aAddB','eLtAB','xLtAB','aReload','aSpill','rLoadPropertyR','rLoadPropertyS','rFromS','sFromR','rReload','sReload','call','callVirtual']:
        if opname not in addresses: continue
        pc=addresses[opname]; visited=[]; calls=[]
        for _ in range(1500):
            if pc==header: break
            op,arg=asm[pc]; visited.append(pc)
            if op=='bl': calls.append(syms.get(target(arg),hex(target(arg))))
            if op=='blr': calls.append('indirect')
            if op in ('ret','br'): break
            pc=target(arg) if op=='b' else pc+4
        else: raise ValueError((name,opname,'loop'))
        paths[opname]={'instructions':len(visited)+(branch-header)//4+1,'helper_calls':calls}
    row={'variant':name,'dispatch_bytes':len(asm)*4,'header_instructions':(branch-header)//4+1,'header_stack_stores':sum(op.startswith('st') and 'x29' in arg for a,(op,arg) in asm.items() if header<=a<=branch),'paths':paths}
    (path/'arm64-summary.json').write_text(json.dumps(row,indent=2))
    rows.append(row)
    print(name,row['dispatch_bytes'],row['header_instructions'],row['header_stack_stores'],{k:v['instructions'] for k,v in paths.items()})
(root/'arm64-comparison.json').write_text(json.dumps(rows,indent=2))
