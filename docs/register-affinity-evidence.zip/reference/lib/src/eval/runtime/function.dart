import 'package:dart_eval/src/eval/runtime/exception.dart';
import 'package:dart_eval/src/eval/shared/stdlib/core/base.dart';
import 'package:dart_eval/src/eval/shared/stdlib/core/num.dart';
import 'package:dart_eval/src/eval/shared/stdlib/core/object.dart';

import '../../../dart_eval_bridge.dart';

/// Typedef of a function that can be called by dart_eval.
typedef EvalCallableFunc =
    $Value? Function(Runtime runtime, $Value? target, List<$Value?> args);

/// Generated static bridge entry. Arguments are canonical language values.
/// Up to three arguments occupy R/S/C. Beyond three, R/S hold the first two
/// and C holds a borrowed `List<Object?>` with the remaining arguments.
/// Read overflow arguments before calling host code; never retain that list.
typedef EvalRegisterFunc =
    $Value? Function(Runtime runtime, Object? r, Object? s, Object? c);

/// Abstract supertype for values representing a callable in dart_eval.
abstract class EvalCallable {
  $Value? call(Runtime runtime, $Value? target, List<$Value?> args);
}

/// Abstract supertype for values representing a [Function] in dart_eval.
///
/// See [$Function] or [$Closure] to wrap an existing Dart function as a
/// [EvalFunction].
abstract class EvalFunction implements $Instance, EvalCallable {
  const EvalFunction();

  @override
  $Value? $getProperty(Runtime runtime, String identifier) {
    switch (identifier) {
      case 'call':
        return this;
      case '==':
        return $Function((runtime, target, args) => $bool(this == args[0]));
      case 'hashCode':
        return $int(hashCode);
      default:
        throw EvalUnknownPropertyException(identifier);
    }
  }

  @override
  void $setProperty(Runtime runtime, String identifier, $Value value) {
    throw EvalUnknownPropertyException(identifier);
  }

  @override
  dynamic get $value => throw UnimplementedError();

  @override
  dynamic get $reified => throw UnimplementedError();
}

/// An implementation of [EvalFunction] that wraps an existing Dart function for
/// use in dart_eval.
///
/// The wrapped function should be of the type
/// ```dart
/// $Value? Function(Runtime runtime, $Value? target, List<$Value?> args)
/// ```
///
/// The target is the object that the function is being called on, or null if
/// the function is being called statically.
///
/// The args are the arguments passed to the function.
///
/// In dynamic invocation / closure contexts such as when passing a function
/// as an argument, use [$Closure] instead.
class $Function extends EvalFunction {
  const $Function(this.func);

  static const $declaration = BridgeClassDef(
    BridgeClassType(BridgeTypeRef(CoreTypes.function)),
    constructors: {},
    wrap: true,
  );

  final EvalCallableFunc func;

  @override
  get $value => func;

  @override
  get $reified => func;

  @override
  $Value? $getProperty(Runtime runtime, String identifier) {
    try {
      return super.$getProperty(runtime, identifier);
    } on UnimplementedError {
      return $Object(this).$getProperty(runtime, identifier);
    } on EvalUnknownPropertyException {
      return $Object(this).$getProperty(runtime, identifier);
    }
  }

  @override
  $Value? call(Runtime runtime, $Value? target, List<$Value?> args) {
    return func(runtime, target, args);
  }

  @override
  int $getRuntimeType(Runtime runtime) =>
      runtime.lookupType(CoreTypes.function);

  @override
  String toString() {
    return 'Function{func: $func}';
  }
}

/// Variant of [$Function] for use in a dynamic invocation / closure context,
/// such as when passing a function as an argument.
class $Closure extends EvalFunction {
  const $Closure(this.func, [this.$this]);

  final EvalCallableFunc func;
  final $Instance? $this;

  @override
  get $value => func;

  @override
  get $reified => func;

  @override
  $Value? $getProperty(Runtime runtime, String identifier) {
    try {
      return super.$getProperty(runtime, identifier);
    } on UnimplementedError {
      return $Object(this).$getProperty(runtime, identifier);
    } on EvalUnknownPropertyException {
      return $Object(this).$getProperty(runtime, identifier);
    }
  }

  @override
  $Value? call(Runtime runtime, $Value? target, List<$Value?> args) {
    return func(runtime, $this ?? target, args);
  }

  @override
  int $getRuntimeType(Runtime runtime) =>
      runtime.lookupType(CoreTypes.function);
}
