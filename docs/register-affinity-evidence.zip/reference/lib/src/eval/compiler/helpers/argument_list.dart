import 'package:analyzer/dart/ast/ast.dart';
import 'package:dart_eval/src/eval/compiler/expression/expression.dart';
import 'package:control_flow_graph/control_flow_graph.dart';
import 'package:dart_eval/src/eval/compiler/helpers/fpl.dart';
import 'package:dart_eval/src/eval/compiler/helpers/tearoff.dart';
import 'default_value.dart';

import '../../../../dart_eval_bridge.dart';
import '../builtins.dart';
import '../context.dart';
import '../errors.dart';
import '../type.dart';

import '../variable.dart';
import '../../ir/bridge.dart' show PrepareBridgeArgument;

Variable _providedBridgeArgument(CompilerContext ctx, Variable argument) {
  final type = argument.type;
  if (!type.nullable &&
      type != CoreTypes.nullType.ref(ctx) &&
      type != CoreTypes.dynamic.ref(ctx)) {
    return argument;
  }
  return Variable.ssa(
    ctx,
    PrepareBridgeArgument(ctx.svar('bridgeArgument'), argument.ssa),
    type,
  );
}

class ArgumentListResult {
  final List<SSA> ssa;
  final List<Variable> args;
  final Map<String, Variable> namedArgs;

  ArgumentListResult(this.ssa, this.args, this.namedArgs);
}

Variable _omittedArgument(
  CompilerContext ctx,
  int library,
  FormalParameter parameter,
  Declaration host,
) {
  if (parameter.isRequired) {
    throw CompileError(
      'Missing required argument ${parameter.name!.lexeme}',
      parameter,
    );
  }
  final (declaredType, _) = getFormalParameterType(
    ctx,
    parameter,
    library,
    host,
  );
  final type = declaredType ?? CoreTypes.dynamic.ref(ctx);
  var value = evaluateDefaultValue(
    ctx,
    library,
    parameter is DefaultFormalParameter ? parameter.defaultValue : null,
  );
  if (value is int && type.file == dartCoreFile && type.name == 'double') {
    value = value.toDouble();
  }
  final variable = pushDefaultValue(ctx, value);
  return host is MethodDeclaration || !type.isUnboxedAcrossFunctionBoundaries
      ? variable.boxIfNeeded(ctx)
      : variable.unboxIfNeeded(ctx);
}

ArgumentListResult compileArgumentList(
  CompilerContext ctx,
  ArgumentList argumentList,
  int decLibrary,
  List<FormalParameter> fpl,
  Declaration parameterHost, {
  List<Variable> before = const [],
  Map<String, TypeRef> resolveGenerics = const {},
  List<String> superParams = const [],
  AstNode? source,
}) {
  final ssa = <SSA>[];
  final args = <Variable>[];
  final push = <Variable>[...before];
  final namedArgs = <String, Variable>{};

  final positional = <FormalParameter>[];
  final named = <String, FormalParameter>{};
  final namedExpr = <String, Expression>{};

  for (final param in fpl) {
    if (param.isNamed) {
      named[param.name!.lexeme] = param;
    } else {
      positional.add(param);
    }
  }

  var i = 0;

  final resolveGenericsMap = <String, Set<TypeRef>>{};

  for (final param in positional) {
    // First check super params. Super params do not contain an expression.
    if (superParams.contains(param.name!.lexeme)) {
      final V = ctx.lookupLocal(param.name!.lexeme)!;
      push.add(V);
      args.add(V);
      i++;
      continue;
    }
    final arg = argumentList.arguments.length <= i
        ? null
        : argumentList.arguments[i];
    if (arg is NamedExpression) {
      if (param.isRequired) {
        throw CompileError('Not enough positional arguments');
      } else {
        final value = _omittedArgument(ctx, decLibrary, param, parameterHost);
        push.add(value);
        args.add(value);
      }
    } else if (arg == null) {
      if (param.isRequired) {
        throw CompileError('Not enough positional arguments');
      } else {
        final value = _omittedArgument(ctx, decLibrary, param, parameterHost);
        push.add(value);
        args.add(value);
      }
    } else {
      var (paramType, typeAnnotation) = getFormalParameterType(
        ctx,
        param,
        decLibrary,
        parameterHost,
        typeParameters: resolveGenerics,
      );

      paramType ??= CoreTypes.dynamic.ref(ctx);

      var arg0 = compileExpression(arg, ctx, paramType);
      if (parameterHost is MethodDeclaration ||
          !paramType.isUnboxedAcrossFunctionBoundaries) {
        arg0 = arg0.boxIfNeeded(ctx);
      } else if (paramType.isUnboxedAcrossFunctionBoundaries) {
        arg0 = arg0.unboxIfNeeded(ctx);
      }

      if (arg0.type == CoreTypes.function.ref(ctx) &&
          arg0.name == null &&
          arg0.methodOffset != null) {
        arg0 = arg0.tearOff(ctx);
      }

      if (!arg0.type.resolveTypeChain(ctx).isAssignableTo(ctx, paramType)) {
        throw CompileError(
          'Cannot assign argument of type ${arg0.type.toStringClear(ctx, paramType)} '
          'to parameter "${param.name!.lexeme}" of type ${paramType.toStringClear(ctx, arg0.type)}',
          source ?? parameterHost,
        );
      }

      if (typeAnnotation != null) {
        final n = typeAnnotation is NamedType
            ? (typeAnnotation.name.stringValue ?? typeAnnotation.name.lexeme)
            : null;
        if (n != null && resolveGenerics.containsKey(n)) {
          resolveGenericsMap[n] ??= {};
          resolveGenericsMap[n]!.add(arg0.type);
        }
      }

      args.add(arg0);
      push.add(arg0);
    }

    i++;
  }

  for (final arg in argumentList.arguments) {
    if (arg is NamedExpression) {
      if (!named.containsKey(arg.name.label.name)) {
        throw CompileError(
          'Unknown named argument ${arg.name.label.name}',
          arg,
        );
      }
      namedExpr[arg.name.label.name] = arg.expression;
    }
  }

  for (final n in named.entries) {
    final name = n.key;
    final param0 = n.value;
    if (superParams.contains(name)) {
      final V = ctx.lookupLocal(name)!;
      push.add(V);
      namedArgs[name] = V;

      continue;
    }
    final param =
        (param0 is DefaultFormalParameter ? param0.parameter : param0)
            as NormalFormalParameter;
    var paramType = CoreTypes.dynamic.ref(ctx);
    TypeAnnotation? typeAnnotation;
    if (param is SimpleFormalParameter) {
      typeAnnotation = param.type;
      if (typeAnnotation != null) {
        paramType =
            typeAnnotation is NamedType &&
                resolveGenerics.containsKey(typeAnnotation.name.lexeme)
            ? resolveGenerics[typeAnnotation.name.lexeme]!.copyWith(
                nullable: typeAnnotation.question != null,
              )
            : TypeRef.fromAnnotation(ctx, decLibrary, typeAnnotation);
      }
    } else if (param is FieldFormalParameter) {
      paramType = resolveFieldFormalType(ctx, decLibrary, param, parameterHost);
    } else if (param is SuperFormalParameter) {
      paramType = resolveSuperFormalType(ctx, decLibrary, param, parameterHost);
    } else {
      throw CompileError('Unknown formal type ${param.runtimeType}');
    }

    if (namedExpr.containsKey(name)) {
      var arg0 = compileExpression(namedExpr[name]!, ctx, paramType);
      if (parameterHost is MethodDeclaration ||
          !paramType.isUnboxedAcrossFunctionBoundaries) {
        arg0 = arg0.boxIfNeeded(ctx);
      } else if (paramType.isUnboxedAcrossFunctionBoundaries) {
        arg0 = arg0.unboxIfNeeded(ctx);
      }

      if (arg0.type == CoreTypes.function.ref(ctx) &&
          arg0.name == null &&
          arg0.methodOffset != null) {
        arg0 = arg0.tearOff(ctx);
      }

      if (!arg0.type.resolveTypeChain(ctx).isAssignableTo(ctx, paramType)) {
        throw CompileError(
          'Cannot assign argument of type ${arg0.type.toStringClear(ctx, paramType)}'
          ' to parameter "${param.name!.lexeme}" of type ${paramType.toStringClear(ctx, arg0.type)}',
          source ?? parameterHost,
        );
      }

      if (typeAnnotation != null) {
        final n = typeAnnotation is NamedType
            ? (typeAnnotation.name.stringValue ?? typeAnnotation.name.lexeme)
            : null;
        if (n != null && resolveGenerics.containsKey(n)) {
          resolveGenericsMap[n] ??= {};
          resolveGenericsMap[n]!.add(arg0.type);
        }
      }

      push.add(arg0);
      namedArgs[name] = arg0;
    } else {
      final value = _omittedArgument(ctx, decLibrary, param0, parameterHost);
      push.add(value);
      namedArgs[name] = value;
    }
  }

  for (final generic in resolveGenericsMap.keys) {
    resolveGenerics[generic] = TypeRef.commonBaseType(
      ctx,
      resolveGenericsMap[generic]!,
    );
  }

  ssa.addAll(push.map((argument) => argument.ssa));
  return ArgumentListResult(ssa, args, namedArgs);
}

ArgumentListResult compileSuperParams(
  CompilerContext ctx,
  List<FormalParameter> fpl,
  Declaration parameterHost, {
  List<Variable> before = const [],
  List<String> superParams = const [],
  AstNode? source,
}) {
  final ssa = <SSA>[];
  final args = <Variable>[];
  final push = <Variable>[...before];
  final namedArgs = <String, Variable>{};

  final positional = <FormalParameter>[];
  final named = <String, FormalParameter>{};

  for (final param in fpl) {
    if (param.isNamed) {
      named[param.name!.lexeme] = param;
    } else {
      positional.add(param);
    }
  }

  for (final param in positional) {
    // First check super params. Super params do not contain an expression.
    if (superParams.contains(param.name!.lexeme)) {
      final V = ctx.lookupLocal(param.name!.lexeme)!;
      push.add(V);
      args.add(V);
    } else {
      if (param.isRequired) {
        throw CompileError('Not enough positional arguments');
      } else {
        final value = _omittedArgument(ctx, ctx.library, param, parameterHost);
        push.add(value);
        args.add(value);
      }
    }
  }

  for (final n in named.entries) {
    final name = n.key;
    if (superParams.contains(name)) {
      final V = ctx.lookupLocal(name)!;
      push.add(V);
      namedArgs[name] = V;
    } else {
      final value = _omittedArgument(ctx, ctx.library, n.value, parameterHost);
      push.add(value);
      namedArgs[name] = value;
    }
  }

  ssa.addAll(push.map((argument) => argument.ssa));
  return ArgumentListResult(ssa, args, namedArgs);
}

ArgumentListResult compileSuperParamsWithBridge(
  CompilerContext ctx,
  BridgeFunctionDef function, {
  List<Variable> before = const [],
  List<String> superParams = const [],
}) {
  final ssa = <SSA>[];
  final args = <Variable>[];
  final push = <Variable>[...before];
  final namedArgs = <String, Variable>{};

  Variable? $null;

  for (final param in function.params) {
    // First check super params. Super params do not contain an expression.
    if (superParams.contains(param.name)) {
      final V = ctx.lookupLocal(param.name)!;
      push.add(V);
      args.add(V);
    } else {
      if (param.optional) {
        $null ??= BuiltinValue().push(ctx);
        push.add($null);
      } else {
        throw CompileError('Not enough positional arguments');
      }
    }
  }

  for (final param in function.namedParams) {
    if (superParams.contains(param.name)) {
      final V = ctx.lookupLocal(param.name)!;
      push.add(V);
      namedArgs[param.name] = V;
    } else {
      $null ??= BuiltinValue().push(ctx);
      push.add($null);
    }
  }

  ssa.addAll(push.map((argument) => argument.ssa));
  return ArgumentListResult(ssa, args, namedArgs);
}

/// Best effort method to compile an argument list against a dynamic target.
/// This will not always work, but it's better than nothing for simple cases.
ArgumentListResult compileArgumentListWithDynamic(
  CompilerContext ctx,
  ArgumentList argumentList, {
  List<Variable> before = const [],
  Map<String, TypeRef> resolveGenerics = const {},
  AstNode? source,
}) {
  final ssa = <SSA>[];
  final args = <Variable>[];
  final push = <Variable>[...before];
  final namedArgs = <String, Variable>{};

  for (var i = 0; i < argumentList.arguments.length; i++) {
    final arg = argumentList.arguments[i];

    if (arg is NamedExpression) {
      throw CompileError(
        'dart_eval does not support passing named arguments '
        'to dynamic targets.',
        source ?? argumentList,
      );
    }

    var arg0 = compileExpression(arg, ctx);
    if (arg0.type == CoreTypes.function.ref(ctx) &&
        arg0.name == null &&
        arg0.methodOffset != null) {
      arg0 = arg0.tearOff(ctx);
    }
    // Dynamic calls use canonical object values for every argument. Their
    // signature cannot justify unboxing a scalar or a collection here.
    arg0 = arg0.boxIfNeeded(ctx);

    args.add(arg0);
    push.add(arg0);
  }

  ssa.addAll(push.map((argument) => argument.ssa));
  return ArgumentListResult(ssa, args, namedArgs);
}

ArgumentListResult compileArgumentListWithKnownMethodArgs(
  CompilerContext ctx,
  ArgumentList argumentList,
  List<KnownMethodArg> params,
  Map<String, KnownMethodArg> namedParams, {
  List<Variable> before = const [],
  AstNode? source,
}) {
  final ssa = <SSA>[];
  final args = <Variable>[];
  final push = <Variable>[...before];
  final namedArgs = <String, Variable>{};
  final namedExpr = <String, Expression>{};

  var i = 0;
  Variable? $null;

  for (final param in params) {
    if (param.optional && argumentList.arguments.length <= i) {
      break;
    }
    final arg = argumentList.arguments[i];
    if (arg is NamedExpression) {
      if (!param.optional) {
        throw CompileError('Not enough positional arguments');
      } else {
        $null ??= BuiltinValue().push(ctx);
        push.add($null);
      }
    } else {
      var paramType = param.type ?? CoreTypes.dynamic.ref(ctx);

      var arg0 = compileExpression(arg, ctx, paramType);
      arg0 = arg0.boxIfNeeded(ctx);

      if (arg0.type == CoreTypes.function.ref(ctx) &&
          arg0.name == null &&
          arg0.methodOffset != null) {
        arg0 = arg0.tearOff(ctx);
      }

      if (!arg0.type.resolveTypeChain(ctx).isAssignableTo(ctx, paramType)) {
        throw CompileError(
          'Cannot assign argument of type ${arg0.type} to parameter of type $paramType',
          argumentList,
        );
      }
      args.add(arg0);
      push.add(arg0);
    }

    i++;
  }

  for (final arg in argumentList.arguments) {
    if (arg is NamedExpression) {
      namedExpr[arg.name.label.name] = arg.expression;
    }
  }

  for (final param in namedParams.values) {
    var paramType = param.type ?? CoreTypes.dynamic.ref(ctx);
    if (namedExpr.containsKey(param.name)) {
      final arg0 = compileExpression(
        namedExpr[param.name]!,
        ctx,
        paramType,
      ).boxIfNeeded(ctx);
      if (!arg0.type.resolveTypeChain(ctx).isAssignableTo(ctx, paramType)) {
        throw CompileError(
          'Cannot assign argument of type ${arg0.type} to parameter of type $paramType',
          source,
        );
      }
      push.add(arg0);
      namedArgs[param.name] = arg0;
    } else {
      $null ??= BuiltinValue().push(ctx);
      push.add($null);
    }
  }

  ssa.addAll(push.map((argument) => argument.ssa));
  return ArgumentListResult(ssa, args, namedArgs);
}

ArgumentListResult compileArgumentListWithBridge(
  CompilerContext ctx,
  ArgumentList argumentList,
  BridgeFunctionDef function, {
  List<Variable> before = const [],
  List<String> superParams = const [],
}) {
  final ssa = <SSA>[];
  final args = <Variable>[];
  final push = <Variable>[...before];
  final namedArgs = <String, Variable>{};
  final namedExpr = <String, Expression>{};

  var i = 0;
  Variable? $null;

  for (final param in function.params) {
    if (superParams.contains(param.name)) {
      final V = _providedBridgeArgument(ctx, ctx.lookupLocal(param.name)!);
      push.add(V);
      args.add(V);

      i++;
      continue;
    }
    if (param.optional && argumentList.arguments.length <= i) {
      $null ??= BuiltinValue().push(ctx);
      push.add($null);

      continue;
    }
    final arg = argumentList.arguments[i];
    if (arg is NamedExpression) {
      if (!param.optional) {
        throw CompileError('Not enough positional arguments');
      } else {
        $null ??= BuiltinValue().push(ctx);
        push.add($null);
      }
    } else {
      var paramType = TypeRef.fromBridgeAnnotation(ctx, param.type);

      var arg0 = compileExpression(arg, ctx, paramType);
      arg0 = arg0.boxIfNeeded(ctx);
      if (arg0.type == CoreTypes.function.ref(ctx) &&
          arg0.name == null &&
          arg0.methodOffset != null) {
        arg0 = arg0.tearOff(ctx);
      }
      if (!(param.type.nullable && arg0.type == CoreTypes.nullType.ref(ctx)) &&
          !arg0.type.resolveTypeChain(ctx).isAssignableTo(ctx, paramType)) {
        throw CompileError(
          'Cannot assign argument of type ${arg0.type} to parameter of type $paramType',
          argumentList,
        );
      }
      arg0 = _providedBridgeArgument(ctx, arg0);
      args.add(arg0);
      push.add(arg0);
    }

    i++;
  }

  for (final arg in argumentList.arguments) {
    if (arg is NamedExpression) {
      namedExpr[arg.name.label.name] = arg.expression;
    }
  }

  for (final param in function.namedParams) {
    if (superParams.contains(param.name)) {
      final V = _providedBridgeArgument(ctx, ctx.lookupLocal(param.name)!);
      push.add(V);
      namedArgs[param.name] = V;
      continue;
    }
    var paramType = TypeRef.fromBridgeAnnotation(ctx, param.type);
    if (namedExpr.containsKey(param.name)) {
      var arg0 = compileExpression(
        namedExpr[param.name]!,
        ctx,
        paramType,
      ).boxIfNeeded(ctx);
      if (arg0.type == CoreTypes.function.ref(ctx) &&
          arg0.name == null &&
          arg0.methodOffset != null) {
        arg0 = arg0.tearOff(ctx);
      }
      if (!arg0.type.resolveTypeChain(ctx).isAssignableTo(ctx, paramType)) {
        throw CompileError(
          'Cannot assign argument of type ${arg0.type} to parameter of type $paramType',
          argumentList,
        );
      }
      arg0 = _providedBridgeArgument(ctx, arg0);
      push.add(arg0);
      namedArgs[param.name] = arg0;
    } else {
      $null ??= BuiltinValue().push(ctx);
      push.add($null);
    }
  }

  ssa.addAll(push.map((argument) => argument.ssa));
  return ArgumentListResult(ssa, args, namedArgs);
}

TypeRef resolveFieldFormalType(
  CompilerContext ctx,
  int decLibrary,
  FieldFormalParameter param,
  Declaration parameterHost,
) {
  if (parameterHost is! ConstructorDeclaration) {
    throw CompileError('Field formals can only occur in constructors');
  }
  final $class = parameterHost.parent as NamedCompilationUnitMember;
  return TypeRef.lookupFieldType(
        ctx,
        TypeRef.lookupDeclaration(ctx, decLibrary, $class),
        param.name.lexeme,
        forFieldFormal: true,
        source: param,
      ) ??
      CoreTypes.dynamic.ref(ctx);
}

TypeRef resolveSuperFormalType(
  CompilerContext ctx,
  int decLibrary,
  SuperFormalParameter param,
  Declaration parameterHost,
) {
  if (parameterHost is! ConstructorDeclaration) {
    throw CompileError('Super formals can only occur in constructors');
  }
  var superConstructorName = '';
  final lastInit = parameterHost.initializers.isEmpty
      ? null
      : parameterHost.initializers.last;
  if (lastInit is SuperConstructorInvocation) {
    superConstructorName = lastInit.constructorName?.name ?? '';
  }
  final $class = parameterHost.parent as ClassDeclaration;
  final type = TypeRef.lookupDeclaration(ctx, decLibrary, $class);
  final $super =
      type.resolveTypeChain(ctx).extendsType ??
      (throw CompileError(
        'Class $type has no super class, so cannot use super formals',
        param,
      ));
  final superCstr =
      ctx.topLevelDeclarationsMap[$super
          .file]!['${$super.name}.$superConstructorName']!;
  if (superCstr.isBridge) {
    final fd = (superCstr.bridge as BridgeConstructorDef).functionDescriptor;
    for (final bridgeParam in (param.isNamed ? fd.namedParams : fd.params)) {
      if (bridgeParam.name == param.name.lexeme) {
        return TypeRef.fromBridgeAnnotation(ctx, bridgeParam.type);
      }
    }
  } else {
    final cstr = superCstr.declaration as ConstructorDeclaration;
    for (final cstrParam in cstr.parameters.parameters) {
      var param0 = cstrParam is DefaultFormalParameter
          ? cstrParam.parameter
          : cstrParam;
      if (param0.name?.lexeme != param.name.lexeme) {
        continue;
      }
      if (param0 is SimpleFormalParameter) {
        final type0 = param0.type;
        if (type0 == null) {
          return CoreTypes.dynamic.ref(ctx);
        }
        return TypeRef.fromAnnotation(ctx, $super.file, type0);
      } else if (param0 is FieldFormalParameter) {
        return resolveFieldFormalType(ctx, decLibrary, param0, cstr);
      } else if (param0 is SuperFormalParameter) {
        return resolveSuperFormalType(ctx, decLibrary, param0, cstr);
      } else {
        throw CompileError(
          'Unknown parameter type ${param0.runtimeType}',
          param0,
        );
      }
    }
  }

  throw CompileError(
    'Could not find parameter ${param.name.value()} in the referenced superclass constructor',
    param,
    decLibrary,
  );
}
