import 'package:dart_eval/src/eval/ir/objects.dart';
import 'package:analyzer/dart/ast/ast.dart';
import 'package:dart_eval/dart_eval_bridge.dart';
import 'package:dart_eval/src/eval/compiler/context.dart';
import 'package:dart_eval/src/eval/compiler/errors.dart';
import 'package:dart_eval/src/eval/compiler/type.dart';
import 'package:dart_eval/src/eval/compiler/variable.dart';

Variable compileThisExpression(ThisExpression e, CompilerContext ctx) {
  if (ctx.currentClass == null) {
    throw CompileError("Cannot use 'this' outside of a class context");
  }
  final receiver = ctx.lookupLocal('#this')!;
  return Variable.ssa(
    ctx,
    LoadThis(ctx.svar('this'), receiver.ssa),
    receiver.type,
  );
}

Variable compileSuperExpression(SuperExpression e, CompilerContext ctx) {
  if (ctx.currentClass == null || ctx.currentClass is! ClassDeclaration) {
    throw CompileError("Cannot use 'super' outside of a class context");
  }

  var type = CoreTypes.object.ref(ctx);
  final extendsClause = (ctx.currentClass as ClassDeclaration).extendsClause;
  if (extendsClause != null) {
    type =
        ctx.visibleTypes[ctx.library]![extendsClause.superclass.name.value()]!;
  }

  final $this = ctx.lookupLocal('#this')!;
  final v = Variable.ssa(
    ctx,
    LoadSuper(ctx.svar('super'), $this.ssa),
    type,
    concreteTypes: [type],
  );
  return v;
}
