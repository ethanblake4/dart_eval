import 'package:dart_eval/dart_eval_bridge.dart';
import 'package:dart_eval/src/eval/runtime/exception.dart';
import 'package:dart_eval/src/eval/runtime/runtime.dart';
import 'package:dart_eval/src/eval/runtime/stdlib/core/collection.dart';
import 'package:dart_eval/src/eval/runtime/stdlib/core/num.dart';

class EvalNull implements EvalValue {
  const EvalNull();

  @override
  Null get $value => null;

  @override
  Null get $reified => null;
}

class EvalObject implements EvalInstance {
  const EvalObject();

  @override
  dynamic get $value => null;

  @override
  dynamic get $reified => $value;

  @override
  EvalValue? $getProperty(Runtime runtime, String identifier) {
    switch (identifier) {
      case '==':
        return __equals;
    }

    throw UnimplementedError();
  }

  static const EvalFunctionImpl __equals = EvalFunctionImpl(_equals);

  static EvalValue? _equals(Runtime runtime, EvalValue? target, List<EvalValue?> args) {
    final other = args[0];
    return EvalBool(target!.$value == other!.$value);
  }

  @override
  void $setProperty(Runtime runtime, String identifier, EvalValue value) {
    throw UnimplementedError();
  }
}

class EvalBool implements EvalInstance {
  EvalBool(this.$value);

  final EvalInstance $super = EvalObject();

  @override
  bool $value;

  @override
  EvalValue? $getProperty(Runtime runtime, String identifier) {
    switch (identifier) {
    }
    return $super.$getProperty(runtime, identifier);
  }

  @override
  void $setProperty(Runtime runtime, String identifier, EvalValue value) {}

  @override
  bool get $reified => $value;

  @override
  bool operator ==(Object other) =>
      identical(this, other) || other is EvalBool && runtimeType == other.runtimeType && $value == other.$value;

  @override
  int get hashCode => $value.hashCode;

  @override
  String toString() {
    return 'EvalBool{${$value}}';
  }
}

class EvalInvocation implements EvalInstance {
  EvalInvocation.getter(this.positionalArguments);

  final EvalInstance $super = EvalObject();

  final $List? positionalArguments;

  @override
  EvalValue? $getProperty(Runtime runtime, String identifier) {
    switch (identifier) {
      case 'positionalArguments':
        return positionalArguments;
    }
  }

  @override
  void $setProperty(Runtime runtime, String identifier, EvalValue value) {}

  @override
  dynamic get $value => throw UnimplementedError();

  @override
  dynamic get $reified => throw UnimplementedError();
}

class EvalString implements EvalInstance {
  const EvalString(this.$value);

  @override
  final String $value;

  final EvalInstance $super = const EvalObject();

  @override
  EvalValue? $getProperty(Runtime runtime, String identifier) {
    switch (identifier) {
      case 'length':
        return EvalInt($value.length);
      case 'isEmpty':
        return EvalBool($value.isEmpty);
      case 'isNotEmpty':
        return EvalBool($value.isNotEmpty);
      case '+':
        return __concat;
      case 'toLowerCase':
        return __toLowerCase;
      case 'toUpperCase':
        return __toUpperCase;
    }

    return $super.$getProperty(runtime, identifier);
  }

  @override
  void $setProperty(Runtime runtime, String identifier, EvalValue value) {
    throw EvalUnknownPropertyException(identifier);
  }

  static const EvalFunctionImpl __concat = EvalFunctionImpl(_concat);

  static EvalValue? _concat(final Runtime runtime, final EvalValue? target, final List<EvalValue?> args) {
    target as EvalString;
    final other = args[0] as EvalString;
    return EvalString(target.$value + other.$value);
  }

  static const EvalFunctionImpl __toLowerCase = EvalFunctionImpl(_toLowerCase);

  static EvalValue? _toLowerCase(final Runtime runtime, final EvalValue? target, final List<EvalValue?> args) {
    return EvalString((target!.$value as String).toLowerCase());
  }

  static const EvalFunctionImpl __toUpperCase = EvalFunctionImpl(_toUpperCase);

  static EvalValue? _toUpperCase(final Runtime runtime, final EvalValue? target, final List<EvalValue?> args) {
    return EvalString((target!.$value as String).toUpperCase());
  }

  @override
  String get $reified => $value;
}