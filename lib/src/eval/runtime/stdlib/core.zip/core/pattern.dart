import '../../../../../dart_eval.dart';
import '../../../../../dart_eval_bridge.dart';

extension $PatternExtension on Pattern {
  $Pattern get $wrapped => $Pattern.wrap(this);
}

class $Pattern implements Pattern, EvalInstance {
  $Pattern.wrap(this.$value);

  @override
  final Pattern $value;

  @override
  Pattern get $reified => $value;

  final EvalInstance evalSuperclass = const EvalObject();

  @override
  EvalValue? $getProperty(Runtime runtime, String identifier) {
    switch(identifier) {
      case 'allMatches':
        return EvalFunctionImpl(__allMatches);
    }
  }

  @override
  void $setProperty(Runtime runtime, String identifier, EvalValue value) {
    // TODO: implement $setProperty
  }

  static const EvalFunctionImpl __allMatches = EvalFunctionImpl(_allMatches);

  static EvalValue? _allMatches(final Runtime runtime, final EvalValue? target, final List<EvalValue?> args) {
    target as EvalValue;
    final string = (args[0] as EvalString).$value;
    return $Iterable<Match>.wrap((target.$value as Pattern).allMatches(string));
  }

  @override
  Iterable<Match> allMatches(String string, [int start = 0]) => $value.allMatches(string, start);

  @override
  Match? matchAsPrefix(String string, [int start = 0]) => $value.matchAsPrefix(string, start);
}


class $Pattern$bridge with BridgeInstance implements Pattern {
  const $Pattern$bridge(List<Object?> _);

  static const $type = BridgeTypeDescriptor('dart:core', 'Pattern', isAbstract: true);

  static const BridgeClass<$Pattern$bridge> $classDef = BridgeClass($type, constructors: {
    '': BridgeConstructor($Pattern$bridge.new, [BridgeParameter(type: EvalTypes.intType)])
  }, methods: {
    'allMatches': BridgeFunction(
        [BridgeParameter(type: EvalTypes.stringType), BridgeParameter(type: EvalTypes.intType, optional: true)]),
    'matchAsPrefix': BridgeFunction(
        [BridgeParameter(type: EvalTypes.stringType), BridgeParameter(type: EvalTypes.intType, optional: true)])
  }, fields: {});

  @override
  EvalValue? $bridgeGet(String identifier) {
    switch (identifier) {
    }
    throw UnimplementedError();
  }

  @override
  void $bridgeSet(String identifier, EvalValue value) {
    throw UnimplementedError();
  }

  @override
  Iterable<Match> allMatches(String string, [int start = 0]) =>
      $_invoke('allMatches', [EvalString(string), EvalInt(start)]);

  @override
  Match? matchAsPrefix(String string, [int start = 0]) =>
      $_invoke('matchAsPrefix', [EvalString(string), EvalInt(start)]);
}