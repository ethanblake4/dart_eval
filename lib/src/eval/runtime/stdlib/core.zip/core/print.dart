import 'package:dart_eval/dart_eval.dart';
import 'package:dart_eval/dart_eval_bridge.dart';
import 'package:dart_eval/src/eval/runtime/override.dart';

void $print(String id, Object? object) => print(runtimeOverride(id) ?? object);

const _$print = EvalFunctionImpl(_print);

EvalValue? _print(Runtime runtime, EvalValue? target, List<EvalValue?> args) {
  print(args[0]!.$reified);
}

EvalFunctionImpl get$print(Runtime _) => _$print;
