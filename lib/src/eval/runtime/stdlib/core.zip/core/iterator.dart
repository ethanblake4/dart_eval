import '../../../../../dart_eval.dart';
import '../../../../../dart_eval_bridge.dart';

class $Iterator<E> implements Iterator, EvalInstance {
  const $Iterator.wrap(this.$value);

  @override
  final Iterator<E> $value;

  @override
  Iterator<E> get $reified => $value;

  final EvalInstance evalSuperclass = const EvalObject();

  @override
  EvalValue? $getProperty(Runtime runtime, String identifier) {
    switch (identifier) {
      case 'current':
        return $value.current as EvalValue;
      case 'moveNext':
        return __moveNext;
    }
  }

  @override
  void $setProperty(Runtime runtime, String identifier, EvalValue value) {
    throw UnimplementedError();
  }

  static const EvalFunctionImpl __moveNext = EvalFunctionImpl(_moveNext);

  static EvalValue? _moveNext(final Runtime runtime, final EvalValue? target, final List<EvalValue?> args) {
    return EvalBool(((target as EvalValue).$value as Iterator).moveNext());
  }

  @override
  E get current => $value.current;

  @override
  bool moveNext() => $value.moveNext();
}

class $Iterator$bridge<E> with BridgeInstance implements Iterator<E> {
  const $Iterator$bridge(List<Object?> _);

  static const $type =
      BridgeTypeDescriptor('dart:core', 'Iterator', isAbstract: true, generics: [BridgeTypeDescriptor(null, 'E')]);

  static const BridgeClass<$Iterator$bridge> $classDef = BridgeClass($type, constructors: {
    '': BridgeConstructor($Iterator$bridge.new, []),
  }, methods: {
    'moveNext': BridgeFunction([]),
  }, fields: {
    'current': BridgeFieldDescriptor(BridgeTypeDescriptor(null, 'E'), sets: false)
  });

  @override
  EvalValue? $bridgeGet(String identifier) {
    switch (identifier) {
      case 'current':
        throw UnimplementedError();
    }
    throw UnimplementedError();
  }

  @override
  bool moveNext() => $_invoke('moveNext', []);

  @override
  E get current => $_get('current');

  @override
  void $bridgeSet(String identifier, EvalValue value) {
    throw UnimplementedError();
  }
}
