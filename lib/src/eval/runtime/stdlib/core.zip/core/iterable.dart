part of 'collection.dart';

class $Iterable$bridge<E> with BridgeInstance<Iterable<E>> implements Iterable<E> {
  const $Iterable$bridge(List<Object?> _);

  @override
  Iterable<E> get $reified => ($value as $Iterable$bridge).map((e) => e.$reified);

  static const $type = BridgeTypeDescriptor('dart:core', 'Iterable', isAbstract: true);

  static const BridgeClass<$Iterable$bridge> $classDef = BridgeClass($type, constructors: {
    '': BridgeConstructor($Iterable$bridge.new, [BridgeParameter(type: EvalTypes.intType)]),
  }, methods: {
    'join': BridgeFunction([BridgeParameter(type: EvalTypes.stringType, optional: true)]),
  }, fields: {});

  @override
  EvalValue? $bridgeGet(String identifier) {
    switch (identifier) {
    }
    throw UnimplementedError();
  }

  @override
  void $bridgeSet(String identifier, EvalValue value) {
    throw UnimplementedError();
  }

  @override
  bool any(bool Function(E element) test) =>
      $_invoke('any', [EvalFunctionImpl((_, __, args) => EvalBool(test(args[0]!.$value)))]);

  @override
  Iterable<R> cast<R>() => Iterable.castFrom<E, R>(this);

  @override
  bool contains(Object? element) => $_invoke('contains', [element == null ? EvalNull() : EvalValueImpl(element)]);

  @override
  E elementAt(int index) => $_invoke('elementAt', [EvalInt(index)]);

  @override
  bool every(bool Function(E element) test) =>
      $_invoke('every', [EvalFunctionImpl((_, __, args) => EvalBool(test(args[0]!.$value)))]);

  @override
  Iterable<T> expand<T>(Iterable<T> Function(E element) toElements) => $_invoke('expand', [
    EvalFunctionImpl((runtime, target, args) => $Iterable.wrap(toElements(args[0]!.$value)))]);

  @override
  E get first => $_get('first');

  @override
  E firstWhere(bool Function(E element) test, {E Function()? orElse}) {
    // TODO: implement firstWhere
    throw UnimplementedError();
  }

  @override
  T fold<T>(T initialValue, T Function(T previousValue, E element) combine) {
    // TODO: implement fold
    throw UnimplementedError();
  }

  @override
  Iterable<E> followedBy(Iterable<E> other) {
    // TODO: implement followedBy
    throw UnimplementedError();
  }

  @override
  void forEach(void Function(E element) action) {
    // TODO: implement forEach
  }

  @override
  // TODO: implement isEmpty
  bool get isEmpty => throw UnimplementedError();

  @override
  // TODO: implement isNotEmpty
  bool get isNotEmpty => throw UnimplementedError();

  @override
  // TODO: implement iterator
  Iterator<E> get iterator => throw UnimplementedError();

  @override
  String join([String separator = ""]) {
    // TODO: implement join
    throw UnimplementedError();
  }

  @override
  // TODO: implement last
  E get last => throw UnimplementedError();

  @override
  E lastWhere(bool Function(E element) test, {E Function()? orElse}) {
    // TODO: implement lastWhere
    throw UnimplementedError();
  }

  @override
  // TODO: implement length
  int get length => throw UnimplementedError();

  @override
  Iterable<T> map<T>(T Function(E e) toElement) {
    // TODO: implement map
    throw UnimplementedError();
  }

  @override
  E reduce(E Function(E value, E element) combine) {
    // TODO: implement reduce
    throw UnimplementedError();
  }

  @override
  // TODO: implement single
  E get single => throw UnimplementedError();

  @override
  E singleWhere(bool Function(E element) test, {E Function()? orElse}) {
    // TODO: implement singleWhere
    throw UnimplementedError();
  }

  @override
  Iterable<E> skip(int count) {
    // TODO: implement skip
    throw UnimplementedError();
  }

  @override
  Iterable<E> skipWhile(bool Function(E value) test) {
    // TODO: implement skipWhile
    throw UnimplementedError();
  }

  @override
  Iterable<E> take(int count) {
    // TODO: implement take
    throw UnimplementedError();
  }

  @override
  Iterable<E> takeWhile(bool Function(E value) test) {
    // TODO: implement takeWhile
    throw UnimplementedError();
  }

  @override
  List<E> toList({bool growable = true}) {
    // TODO: implement toList
    throw UnimplementedError();
  }

  @override
  Set<E> toSet() {
    // TODO: implement toSet
    throw UnimplementedError();
  }

  @override
  Iterable<E> where(bool Function(E element) test) {
    // TODO: implement where
    throw UnimplementedError();
  }

  @override
  Iterable<T> whereType<T>() {
    // TODO: implement whereType
    throw UnimplementedError();
  }
}

class $Iterable<E> implements Iterable<E>, EvalInstance {
  $Iterable(String id, Iterable<E> value) : $value = runtimeOverride(id) as Iterable<E>? ?? value;

  $Iterable.wrap(this.$value);

  @override
  final Iterable<E> $value;

  @override
  Iterable<E> get $reified => $value;

  final EvalInstance $super = const EvalObject();

  @override
  EvalValue? $getProperty(Runtime runtime, String identifier) {
    switch (identifier) {
      case 'join':
        return EvalFunctionImpl(__join);
    }
  }

  @override
  void $setProperty(Runtime runtime, String identifier, EvalValue value) {
    // TODO: implement $setProperty
  }

  static const EvalFunctionImpl __join = EvalFunctionImpl(_join);

  static EvalValue? _join(Runtime runtime, EvalValue? target, List<EvalValue?> args) {
    final separator = (args[0] as String?) ?? '';
    return EvalString((target!.$value as Iterable).join(separator));
  }

  @override
  bool any(bool Function(E element) test) => $value.any(test);

  @override
  Iterable<R> cast<R>() => $value.cast<R>();

  @override
  bool contains(Object? element) => $value.contains(element);

  @override
  E elementAt(int index) => $value.elementAt(index);

  @override
  bool every(bool Function(E element) test) => $value.every(test);

  @override
  Iterable<T> expand<T>(Iterable<T> Function(E element) toElements) => $value.expand<T>(toElements);

  @override
  E get first => $value.first;

  @override
  E firstWhere(bool Function(E element) test, {E Function()? orElse}) => $value.firstWhere(test, orElse: orElse);

  @override
  T fold<T>(T initialValue, T Function(T previousValue, E element) combine) => $value.fold(initialValue, combine);

  @override
  Iterable<E> followedBy(Iterable<E> other) => $value.followedBy(other);

  @override
  void forEach(void Function(E element) action) => $value.forEach(action);

  @override
  bool get isEmpty => $value.isEmpty;

  @override
  bool get isNotEmpty => $value.isNotEmpty;

  @override
  Iterator<E> get iterator => $value.iterator;

  @override
  String join([String separator = '']) => $value.join(separator);

  @override
  E get last => $value.last;

  @override
  E lastWhere(bool Function(E element) test, {E Function()? orElse}) => $value.lastWhere(test, orElse: orElse);

  @override
  int get length => $value.length;

  @override
  Iterable<T> map<T>(T Function(E e) toElement) => $value.map(toElement);

  @override
  E reduce(E Function(E value, E element) combine) => $value.reduce(combine);

  @override
  E get single => $value.single;

  @override
  E singleWhere(bool Function(E element) test, {E Function()? orElse}) => $value.singleWhere(test, orElse: orElse);

  @override
  Iterable<E> skip(int count) => $value.skip(count);

  @override
  Iterable<E> skipWhile(bool Function(E value) test) => $value.skipWhile(test);

  @override
  Iterable<E> take(int count) => $value.take(count);

  @override
  Iterable<E> takeWhile(bool Function(E value) test) => $value.takeWhile(test);

  @override
  List<E> toList({bool growable = true}) => $value.toList(growable: growable);

  @override
  Set<E> toSet() => $value.toSet();

  @override
  Iterable<E> where(bool Function(E element) test) => $value.where(test);

  @override
  Iterable<T> whereType<T>() => $value.whereType<T>();
}

class Key {
  Key();
}

abstract class Widget {
  Widget({Key? key});

  Widget build();
}

class Text extends Widget {
  Text(String text, {Key? key}): super(key: key);

  @override
  Widget build() {
    throw UnimplementedError();
  }
}

class MyWidget extends Widget {
  MyWidget({Key? key}): super(key: key);

  MyWidget.withList(this.text, {Key? key});

  Text? text;
  Function(String)? _callback;

  @override
  Widget build() {
    if (text != null) {
      _callback?.call('Has text');
      return text!;
    }

    return Text('Default');
  }

  bool setCallback(Function(String) callback) {
    _callback = callback;
    return true;
  }
}

class $MyWidget implements MyWidget, EvalInstance {

  $MyWidget(String id, {Key? key}) : $value = runtimeOverride(id) as MyWidget? ?? MyWidget(key: key);

  $MyWidget.wrap(this.$value);

  @override
  final MyWidget $value;

  @override
  Function(String p1)? _callback;

  @override
  Text? get text => $value.text;

  @override
  EvalValue? $getProperty(Runtime runtime, String identifier) {
    switch(identifier) {
      case 'text':
        return $Text.wrap($value.text);
    }
  }

  @override
  // TODO: implement $reified
  get $reified => throw UnimplementedError();

  @override
  void $setProperty(Runtime runtime, String identifier, EvalValue value) {
    // TODO: implement $setProperty
  }

  @override
  // TODO: implement $value
  get $value => throw UnimplementedError();

  @override
  Widget build() {
    // TODO: implement build
    throw UnimplementedError();
  }

  @override
  bool setCallback(Function(String p1) callback) {
    // TODO: implement setCallback
    throw UnimplementedError();
  }

}